﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TutorialGifAnimation : MonoBehaviour
{
    public Texture2D[] _pngArray;
    public float _timeToNextImg = 0.25f;

    RawImage _imgComponent;
    int _imgIndex;
    float _lastChangeTime;
    private void Awake() {
        _imgComponent = GetComponent<RawImage>();
    }
    void Start()
    {
        _lastChangeTime = Time.time;
    }
    void Update()
    {
        if (!gameObject.activeInHierarchy)
            return;
        if (_lastChangeTime + _timeToNextImg > Time.time)
            return;
        _imgComponent.texture = _pngArray[_imgIndex++];
        _imgIndex = _imgIndex % _pngArray.Length;
        _lastChangeTime = Time.time;
    }
}
