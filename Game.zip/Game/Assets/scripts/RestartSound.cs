﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RestartSound : MonoBehaviour
{
    public AudioSource audioSource;

    // Start is called before the first frame update
    void Start()
    {
        audioSource = GetComponent<AudioSource>();
    }

    /// <summary>
    /// Play sound when restart button gets activated
    /// </summary>
    public void Play()
    {
        audioSource.Play();
    }

}
