﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SeeschlangeSound : MonoBehaviour
{
    public AudioSource[] sources;
    private enum Soundids
    {
        screech,
        screech2,
        noise,
        heartbeat
    };
    private bool _movmentStarted = false;

    // Start is called before the first frame update
    void Start()
    {
        sources = GetComponents<AudioSource>();
    }

    private void Update()
    {
        if (_movmentStarted)
        {
            if (sources[(int)Soundids.screech].isPlaying 
                || sources[(int)Soundids.screech2].isPlaying)
            {
                return;
            }
            PlayScream();
        }
    }

    public void PlayScream()
    {

        int index = Random.Range(0, 2);
        if (sources[index] == null)
        {
            return;
        }

        sources[index].Play();
        if (!_movmentStarted)
        {
            _movmentStarted = true;
        }
    }

    public void PlayNoise()
    {
        if (sources[(int)Soundids.noise] == null)
        {
            return;
        }
        sources[(int)Soundids.noise].Play();
     }

    public void PlayHeartBeat()
    {
        if (sources[(int)Soundids.heartbeat] == null)
        {
            return;
        }
        sources[(int)Soundids.heartbeat].Play();
    }

    public void PlayScreechOneShot()
    {
        if (sources[(int)Soundids.screech] == null)
        {
            return;
        }
        sources[(int)Soundids.screech].PlayOneShot(sources[(int)Soundids.screech].clip);
    }
}
