﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.Video;


public class video_Gameover : MonoBehaviour
{
    private VideoPlayer videoPlayer;

    void Start() {
        videoPlayer = GetComponent<UnityEngine.Video.VideoPlayer>();
        videoPlayer.loopPointReached += EndReached;
    }

    void EndReached(VideoPlayer vid) {
        SceneManager.LoadScene("ScoreTable");
    }
}
