﻿

using System.Collections;
using System.Collections.Generic;
using System;
using UnityEngine;
using UnityEngine.UI;

using System.Text;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using Audio;
//using PlayerData.cs;


public class udp_receive : MonoBehaviour
{
    // receiving Thread
    Thread receiveThread;

    // udpclient object
    UdpClient client;

    // public
    // public string IP = "127.0.0.1"; default local
    public int port; // define > init

    // infos
    public string lastReceivedUDPPacket = "";
    public string allReceivedUDPPackets = ""; // clean up this from time to time!

    public string receivedMsg;
    public float forceMultipication;
    public float maxSpeedValue = 50;

    public float timeToHit = 0.1f;
    
    private GameManager gameManager;
    private bool threatRunning = true;
    private List<UdpDataRec> udpData;
    private AudioManager audioManager;

    private float[] hitTimes = new float[8];

    //Time Var Martin
    private DateTime[] dateTimes = new DateTime[8];
    private bool firsttime = true;
    private int j = 1;
    
    private int playerCount;
    private float countForceMlut;
    public double delayTime = 150;

    private void Awake()
    {
        playerCount = PlayerData.getCount();

        //nur für Debug-Zwecke
        if (playerCount <= 0)
            playerCount = 1;

        switch (playerCount)
        {
            case 1:
                countForceMlut = 1;
                break;
            case 2:
                countForceMlut = 0.8f;
                break;
            case 3:
                countForceMlut = 0.6f;
                break;
            case 4:
                countForceMlut = 0.4f;
                break;
        }
        udpData = new List<UdpDataRec>();
        audioManager = FindObjectOfType<AudioManager>();
        gameManager = FindObjectOfType<GameManager>();
        init();
    }
    private void init()
    {
        //Text initialisieren oder so

        // define port
        port = 8051;

        // ----------------------------
        // Abhören
        // ----------------------------
        // Lokalen Endpunkt definieren (wo Nachrichten empfangen werden).
        // Einen neuen Thread für den Empfang eingehender Nachrichten erstellen.
        Debug.Log("start thread");
        receiveThread = new Thread(
            new ThreadStart(ReceiveData));
        receiveThread.IsBackground = true;
        receiveThread.Start();
    }

    // receive thread
    private void ReceiveData()
    {
        Debug.Log("thread started");
        client = new UdpClient(port);
        while (threatRunning)
        {
            try
            {
                // Bytes empfangen.
                IPEndPoint anyIP = new IPEndPoint(IPAddress.Any, 0);
                byte[] data = client.Receive(ref anyIP);
                // Bytes mit der UTF8-Kodierung in das Textformat kodieren.
                string udpText = Encoding.UTF8.GetString(data);

                UdpDataRec playerDataNew = getJasonDatafromTxt(udpText);
                playerDataNew.ip = anyIP.Address.ToString();

                if (PlayerData.existsId(playerDataNew.id) == -1 && PlayerData.getCount() > 0) {
                    continue;
                }
                udpData.Add(playerDataNew);

                // Den abgerufenen Text anzeigen.
                //print(">> " + udpText);
                receivedMsg = udpText;

                // latest UDPpacket
                lastReceivedUDPPacket = udpText;

                // ....
                //allReceivedUDPPackets = allReceivedUDPPackets + "\n" + text;
                Thread.Sleep(1);

            }
            catch (Exception err)
            {
                print(err);
            }

            // yield return new WaitForSecondsRealtime(0.001f);
        }
    }

    private bool isNewHit(UdpDataRec data)
    {
        int index = PlayerData.existsId(data.id) * 2;
        if (index < 0)
            return false;
        if (data.side == 1)
            index++;
        else if (data.side != -1)
            return false;

        bool newHit = false;
        if ((Time.time - hitTimes[index]) > timeToHit)
            newHit = true;

        //Debug.Log("Time:" + (Time.time - hitTimes[index]).ToString() + " -> newHit: "+newHit);
        hitTimes[index] = Time.time;

        return newHit;
    }

        // getLatestUDPPacket
        // cleans up the rest
        public string getLatestUDPPacket()
    {
        allReceivedUDPPackets = "";
        return lastReceivedUDPPacket;
    }

    // Update is called once per frame
    void Update()
    {        
        while(udpData.Count > 0)
        {
            if (udpData[0].state == "running")
            {
                gameManager.pauseGame(false);
            }
            if (udpData[0].state == "pause")
            {
                gameManager.pauseGame(true);
            }

            if (udpData[0].state == "restart")
                gameManager.endGame();
            addForce(udpData[0].side, udpData[0].speed, Time.deltaTime, isNewHit(udpData[0]));
            udpData.Remove(udpData[0]);
        }
    }

    public UdpDataRec getJasonDatafromTxt(String text)
    {
        UdpDataRec playerData = new UdpDataRec();
        playerData = JsonUtility.FromJson<UdpDataRec>(text);
        return playerData;
    }

    public void OnDestroy()
    {
        threatRunning = false;
        if (client != null)
            client.Close();
        if (receiveThread.IsAlive)
            receiveThread.Abort();
    }

    public void OnApplicationQuit()
    {
        threatRunning = false;
        if (client != null)
            client.Close();
        if (receiveThread.IsAlive)
            receiveThread.Abort();
    }

 //   private void addForce(float time)
 //   {
 //       if (udpData.side != 0 && udpData.speed > 0.0001)
 //           gameManager.addForceToKayak(udpData.side,
 //               udpData.speed * forceMultipication * time);
 //       udpData.side = 0;
 //       udpData.speed = 0;
 //   }

    private void addForce(int side, float speed, float time, bool newHit = false)
    {
        if (speed > maxSpeedValue)
            speed = maxSpeedValue;
        if (side != 0 && (speed > 0.0001 || speed < -0.0001))
        {
            Debug.Log("recive-speed: " + speed);
            gameManager.addForceToKayak(side, speed * forceMultipication * time * countForceMlut, newHit, speed/maxSpeedValue);
        }
    }
}
