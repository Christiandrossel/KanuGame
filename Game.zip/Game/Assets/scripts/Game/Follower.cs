﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Follower : MonoBehaviour
{
    public Transform Target;
   // public Transform[] riverPath;
    public float distOffset = 1f;
    public float speed = 10.0f;
    public bool m_bMovement = false;
    public string loadScene;

    private int currentPath;
    private Vector3 startPosition;
    const float a = 1.5f;

    private float timer = 0;
    private float timerMax = 0;


    GameManager gameManager;
    private void Awake()
    {
        gameManager = FindObjectOfType<GameManager>();
    }
    // Start is called before the first frame update
    void Start()
    {
        startPosition = transform.position;
    }

    // Update is called once per frame
    void Update()
    {
        float distTarget = (transform.position - Target.position).magnitude;
        //Debug.Log("Distanz" + distTarget);
        PlayerData.setDistance(distTarget);
        if (m_bMovement)
        {
            Vector3 direction = Vector3.Normalize(Target.position - transform.position);
            if (distTarget < speed * Time.deltaTime)
                transform.Translate(direction * distTarget);
            else
                transform.Translate(direction * speed * Time.deltaTime);
            distTarget = (transform.position - Target.position).magnitude;
            

        }
        gameManager.setDist(distTarget - distOffset);

        if (distTarget <= distOffset)
        {
            gameManager.gameOver();
            if (!Waited(2)) return; // Wartezeit: 2 Sekunden
            //SceneManager.LoadScene(loadScene);
           
            
        }
        if (Input.GetKey(KeyCode.S))
        {
            m_bMovement = false;
        }
        if (Input.GetKey(KeyCode.W))
        {
            m_bMovement = true;
        }
    }

    private bool Waited(float seconds)
    {
        timerMax = seconds;

        timer += Time.deltaTime;

        if (timer >= timerMax)
        {
            return true;
        }

        return false;
    }
    
    public void resetPosition()
    {
        transform.position = startPosition;
    }

    public void setMonsterMove(bool p_movment)
    {
        m_bMovement = p_movment;
    }

    public void OnCollisionEnter(Collision colliderinfo)
    {
        if (colliderinfo.gameObject.tag == "Player")
        {
            Debug.Log("GameOver");
            //gameManager.gameOver();
            //GetComponent<BoxCollider>().enabled = false;
        }
    }
}

