﻿using System.Collections;
using System.Collections.Generic;
using System;
using UnityEngine;
using Audio;

//TODO: Arverage Rotation(x,z) from Water:
//https://wiki.unity3d.com/index.php/Averaging_Quaternions_and_Vectors


public class Kayak : MonoBehaviour
{
    //public variables
    public Transform forcePointLeft;
    public Transform forcePointRight;
//    public float forceSteer = 5f;
    public float forceForward = 5f;
    public float steerSpeed = 10;
    public float speedMax = 3f;
    public float steerMax = 6f;
    public float forcePointDist = 0.5f;
    public float rotUpSpeed = 10;
    public float dragReed = 2.5f;
    public float caveForceDumper = 0.5f;

    //private variables
    private Vector3 positionStart;
    private Quaternion rotationStart;
    private Rigidbody rb;
    private GameManager gameManager;
    private AudioManager audioManager;
    private pathLine pathLine;
    private bool bDrag = false;

    float rotationAngle = 0f;
    float smoothTime = 10.0f;
    float rotation = 1.0f;	   
    

    private void Awake()
    {
        positionStart = transform.position;
        rotationStart = transform.localRotation;

        rb = GetComponent<Rigidbody>();
        gameManager = FindObjectOfType<GameManager>();
        audioManager = FindObjectOfType<AudioManager>();
        pathLine = GetComponent<pathLine>();

        forcePointLeft.position = positionStart + new Vector3(-forcePointDist, 0, 0);
        forcePointRight.position = positionStart + new Vector3(forcePointDist, 0, 0);
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        //set from paddel
        if (true) //keyboard control for debug
        {
            if (Input.GetKey(KeyCode.Q))
            {
                addForce(-1, forceForward * Time.deltaTime);
            }
            if (Input.GetKey(KeyCode.A))
            {
                addForce(-1, -forceForward * Time.deltaTime);
            }
            if (Input.GetKey(KeyCode.E))
            {
                addForce(1, forceForward * Time.deltaTime);
            }
            if (Input.GetKey(KeyCode.D))
            {
                addForce(1, -forceForward * Time.deltaTime);
            }
        }
        rotateForward();
        pathLine.riverCraft();
        checkMaxForce();
        
        //set kayak upwards in Water
        if (transform.eulerAngles.z > 20 && transform.eulerAngles.z < 330){
            Quaternion desiredRotation = Quaternion.Euler(transform.rotation.x, transform.rotation.y, rotationAngle);
            transform.rotation = Quaternion.Lerp(transform.rotation, desiredRotation, smoothTime * Time.deltaTime);
        }
    }

    public void OnCollisionEnter(Collision col)
    {
        if (col.gameObject.tag == "water")
            return;
        if(col.gameObject.tag == "Enemy") {
            audioManager.CollisionSeaMonster(col.contacts[0].point);
            return;
        }
        audioManager.CollisionRock(col.contacts[0].point);
    }

    public void OnTriggerExit(Collider other)
    {
        if(other.tag == "reed")
        {
            rb.drag = 0;
        }
    }

    public void OnTriggerEnter(Collider trigger)
    {
        //Debug.Log("tag: " + col.tag);
        //points for colactables
        if (trigger.tag == "colect")
        {
            gameManager.txtPoints.enabled = true;
            Destroy(trigger.gameObject);
        }
        if (trigger.tag == "coin_glod"){
            gameManager.addPoints(100);
            audioManager.CollectCoinGold();
            Destroy(trigger.gameObject);
        }
        if (trigger.tag == "coin"){
            gameManager.addPoints(50);
            audioManager.CollectCoinSilver();
            Destroy(trigger.gameObject);
        }
        if (trigger.tag == "clock"){
            gameManager.addPoints(100);
            audioManager.CollectStuff();
            Destroy(trigger.gameObject);
        }
        if (trigger.tag == "duck"){
            gameManager.addPoints(100);
            audioManager.CollectStuff();
            Destroy(trigger.gameObject);
        }
        if (trigger.tag == "stuff"){
            audioManager.CollectStuff();
            Destroy(trigger.gameObject);
        }
        if (trigger.tag == "startMonster"){
            gameManager.setMonsterMovement(true);
        }
        if (trigger.tag == "Finish") {
            gameManager.finishGame();
        }
        if (trigger.tag == "reed"){
            rb.drag = dragReed;
            audioManager.Grass(transform.position);
        }
        if(trigger.tag == "StartPath"){
            pathLine.startPathLine = true;
        }
        if(trigger.tag == "difficultWay")
        {
            pathLine.difficultWay01(true);
        }
        if(trigger.tag == "difficultWay2")
        {
            pathLine.difficultWay02(true);
        }
        if (trigger.tag == "superClue") {
            gameManager.awakeDave();
            audioManager.CollectGlue();
            Destroy(trigger.gameObject);
        }
        if (trigger.tag == "crow") {
            audioManager.Crow(transform.position);
        }
        if (trigger.tag == "leaveCave") {
            caveForceDumper = 1;
        }
    }

    public void resetPosition()
    {
        transform.SetPositionAndRotation(positionStart, rotationStart);
        rb.velocity *= 0;
        rb.angularVelocity *= 0;
    }

    /// <summary>
    /// Add a force to Rigidbody
    /// </summary>
    /// <param name="side">1 for Right | -1 for Left</param>
    /// <param name="force">force to add</param>
    /// <param name="newHit">defines if hit on watter makes a sound</param>
    public void addForce(int side/*1-right|-1-left*/, float force, bool newHit = false, float soundForce = 1)
    {
        //Add ForcesForward
        if (side == 1)
        {
            rb.AddForceAtPosition(transform.forward * force * caveForceDumper, forcePointRight.position);
            if(newHit)
                audioManager.Paddle(forcePointRight, soundForce);
        }
        else if (side == -1)
        {
            rb.AddForceAtPosition(transform.forward * force * caveForceDumper, forcePointLeft.position);
            if(newHit)
                audioManager.Paddle(forcePointLeft, soundForce);
        }       

        //Debug.Log("side: "+side+"  | speed: " + rb.velocity.magnitude + "  | add: " +force);
               
    }

    private void checkMaxForce()
    {
        //test max steer
        if (rb.angularVelocity.magnitude != 0 && rb.angularVelocity.magnitude > steerMax)
            rb.angularVelocity = rb.angularVelocity / rb.angularVelocity.magnitude * steerMax;
        
        //test max speed
        if (rb.velocity.magnitude > speedMax * caveForceDumper)
            rb.velocity= rb.velocity/ rb.velocity.magnitude * speedMax * caveForceDumper;

        //Debug.Log("speed: " + rb.velocity.magnitude + "  | steer: " + rb.angularVelocity.magnitude);

    }
    private void rotateForward()
    {
        Vector3 direction = new Vector3(transform.forward.x, 0, transform.forward.z);

        Vector3 velocityForward = new Vector3(rb.velocity.x, 0, rb.velocity.z);
        float velocityY = rb.velocity.y;

        //turn force in direction
        if (Vector3.Angle(direction.normalized, velocityForward) < 90)
            velocityForward = Vector3.RotateTowards(velocityForward, direction.normalized.normalized, steerSpeed, 0.0f);
        //velocityForward = direction.normalized.normalized * velocityMagnitude;
        else //backwards
            velocityForward = Vector3.RotateTowards(velocityForward, -direction.normalized.normalized, steerSpeed, 0.0f);
        //velocityForward = -direction.normalized.normalized * velocityMagnitude;

        rb.velocity = new Vector3(velocityForward.x, velocityY, velocityForward.z);
    }

    private void setForcePoints(int numOfPlayer)
    {
        float dist = 0.9f;
        forcePointLeft.position = transform.position + new Vector3(0, 0, -dist);
        forcePointRight.position = transform.position + new Vector3(0, 0, dist);
    }
}
