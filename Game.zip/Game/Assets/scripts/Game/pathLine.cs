﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class pathLine : MonoBehaviour
{
    [Tooltip("Für Trigger (Plane) Aktion im Skript Kayak gedacht!")]
    public bool startPathLine = false;
    [Tooltip("Für Trigger Aktion im Skript Kayak gedacht!")]
    public bool startdifficultWay01 = false;
    [Tooltip("Für Trigger Aktion im Skript Kayak gedacht!")]
    public bool startdifficultWay02 = false;

    int current = 0;

    [Tooltip("Anzahl der Punkte: ")]
    public int Size = 130;
    [Tooltip("Die FLuss-Kraft: ")]
    public float RiverFoce = 3;
    //--Für MovePathLine--
    [Tooltip("Punkte Ein-/Ausschalten (Sollten immer an sein, damit eine Kraft existiert!)")]
    public bool withPath = true;
    [Tooltip("Eine Distanz um den Punkt. Wenn der Spieler sich in dieser Distanz befindet, wird der nächste Punkt anvisiert")]
    public float distancePath = 15;

    [Tooltip("Ein/ Ausschalten der Rotationsbegrenzung")]
    public bool withRotationRetriction=true;
    [Tooltip("Wirkende Kraft die Kayak in Flussrichtung drückt und abhält über 90 Grad zu drehen")]

    public float rotationForceMin = 10f;
    public float rotationForceMax = 70f;
    public float angleMax = 90f;
    public float interpolatevar = 0.0f;
    public float linearInterpolate = 15;

    private Rigidbody rb;
    private GameObject path;
    private List<GameObject> pathList = new List<GameObject>();
    private GameObject nextPath;

    private void Awake()
    {
        rb = GetComponent<Rigidbody>();
    }


    void Start()
    {
        current = 0;
        if (withPath)
        {
            path = GameObject.Find("Path (" + current + ")");
            nextPath = GameObject.Find("Path (" + (current + 2)+ ")");
            Debug.Log("Path:" + path + " and nextPath: " + nextPath);

            
            for(int i=0; i < Size; i++)
            {
                pathList.Add(GameObject.Find("Path (" + i + ")"));
            }
        }
    }

    public void riverCraft()
    {
        if (startPathLine)
        {
            if (withPath)
                pathForce();
            if(withRotationRetriction)
                rotation();
        }

        //Difficult way ends
        if(startdifficultWay01 == true)
        {
            if (current > 114)
            {
                current = 45;
                startdifficultWay01 = false;

            }
        }

        if(startdifficultWay02 == true)
        {
            //Difficult way ends
            if (current > 127)
            {
                current = 38;
                startdifficultWay01 = false;

            }
        }



    }

    // Die Flusskraft
    public void pathForce()
    {

        if (Vector3.Distance(nextPath.transform.position, transform.position) <= distancePath)
        {
            if (current <= Size)
            {
                current++;
                path = GameObject.Find("Path (" + current + ")");
                nextPath = GameObject.Find("Path (" + (current + 2) + ")");
            }
        }
        Vector3 directionVector = DirectionVectorNormalize();
        //Debug.Log("directionVector: " + directionVector);
        //Debug.Log("Aktueller Path: " + path + "     nextPath: " + nextPath);
        rb.AddForce(directionVector * RiverFoce * Time.deltaTime, ForceMode.VelocityChange);         //ForceMode.Impulse bringt eine dauerhafte Kraft mit sich aber auch Ruckeln
        Debug.DrawRay(transform.position, directionVector * RiverFoce *50, Color.yellow);
    }

    public void difficultWay01(bool startdifficultWay)
    {
        startdifficultWay01 = startdifficultWay;
        if (startdifficultWay01 == true)
        {
            //withPath = false;
            current = 54;
            Debug.Log("Start difficult Way 01");
            path = GameObject.Find("Path (" + current + ")");
            nextPath = GameObject.Find("Path (" + (current + 2) + ")");
            Debug.Log("Path:" + path + " and nextPath: " + nextPath);
            Vector3 directionVector = DirectionVectorNormalize();
        }
    }

    public void difficultWay02(bool startdifficultWay)
    {
        startdifficultWay02 = startdifficultWay;
        if (startdifficultWay02 == true)
        {
            //withPath = false;
            current = 122;
            Debug.Log("Start difficult Way 02");
            path = GameObject.Find("Path (" + current + ")");
            nextPath = GameObject.Find("Path (" + (current + 2) + ")");
            Debug.Log("Path:" + path + " and nextPath: " + nextPath);
            Vector3 directionVector = DirectionVectorNormalize();

        }
    }

    Vector3 DirectionVectorNormalize()
    {
        Vector3 directionVector = nextPath.transform.position - path.transform.position;           
        directionVector = Vector3.Normalize(directionVector);
        directionVector.y = 0.0f;
        return directionVector;
    }

    double ForceRotation(float angle)
    {
        double f = 0.03f;
            f=Math.Log(Math.E, f * angle);
        

        return f;
    }

    public float getForceFromAngle(float angle, float angleMax)
    {
        float result = Mathf.Lerp(rotationForceMin, rotationForceMax, angle/angleMax);
        result = Mathf.Pow(result / linearInterpolate, 1.8f);
        //Debug.Log("interpolate Angle: " + result);

        return result;
    }

    public void rotation()
    {
        Vector3 directionVector = DirectionVectorNormalize();
        float angle = stopRotationWithVector();
        //Quaternion rotation = Quaternion.Euler(directionVector);
        //rb.rotation = Quaternion.Slerp(transform.rotation, rotation, rotationForce/* =0.01 */ * Time.deltaTime);

        //    Quaternion slerpDistance = Quaternion.Slerp(transform.rotation, rotation, rotationForce/* =0.01 */);
        //
        //    if (angle > 45)
        //    {
        //        rb.MoveRotation(rotation * slerpDistance);
        //        if (angle > 90)
        //        {
        //            var angleVelo = rb.angularVelocity;
        //            rb.angularVelocity = -angleVelo/2;
        //        }
        //    } 
        float force = getForceFromAngle(angle, angleMax);
        float angleLeftSide = stopRotationWithVectorLeft();
        float angleRightSide = stopRotationWithVectorRight();

        if(angleLeftSide < 90 && angleLeftSide > 0)
        {
            rb.AddTorque(Vector3.up * force);
            //Debug.Log("angleLeftSide: " + angleLeftSide);
        }

        if(angleRightSide < 90 && angleRightSide > 0)
        {
            rb.AddTorque(Vector3.down * force);
            //Debug.Log("angleRightSide: " + angleRightSide);
        }
       // rb.AddTorque(Vector3.down * force);

        //wenn Vector3.down dann zieht er nach links
        //wenn Vector3.up dann zieht er nach rechts
        
    }

    public void rotation(float rotationForce)
    {
        Vector3 directionVector = DirectionVectorNormalize();
        float angle = stopRotationWithVector();
        Quaternion rotation = Quaternion.Euler(directionVector);

        Quaternion slerpDistance = Quaternion.Slerp(transform.rotation, rotation, rotationForce/* =0.01 */ * Time.deltaTime);

        if (angle > 45)
        {
            rb.MoveRotation(rotation * slerpDistance);
            if (angle > 90)
            {
                var angleVelo = rb.angularVelocity;
                rb.angularVelocity = -angleVelo / 2;
            }
        }
    }

    public float stopRotationWithVector()
    {
        Vector3 kayakvec = transform.forward;
        Vector3 directionVector = DirectionVectorNormalize();

        Vector3 limitedVectorRight = Vector3.Cross(Vector3.up, directionVector);
        limitedVectorRight = Vector3.Normalize(limitedVectorRight);
        limitedVectorRight.y = 0.0f;

        Vector3 limitedVectorLeft = Vector3.Cross(Vector3.down, directionVector);
        limitedVectorLeft = Vector3.Normalize(limitedVectorLeft);
        limitedVectorLeft.y = 0.0f;

        Debug.DrawRay(transform.position, limitedVectorLeft * 10, Color.red);
        Debug.DrawRay(transform.position, limitedVectorRight * 10, Color.red);
        Debug.DrawRay(transform.position, rb.velocity, Color.blue);
        float angle = Vector3.Angle(directionVector, kayakvec);
        //Debug.Log("Angle: " + angle);

        return angle;


    }

    public float stopRotationWithVectorLeft()
    {
        Vector3 kayakvec = transform.forward;
        Vector3 directionVector = DirectionVectorNormalize();

        Vector3 limitedVectorRight = Vector3.Cross(Vector3.up, directionVector);
        limitedVectorRight = Vector3.Normalize(limitedVectorRight);
        limitedVectorRight.y = 0.0f;

        Vector3 limitedVectorLeft = Vector3.Cross(Vector3.down, directionVector);
        limitedVectorLeft = Vector3.Normalize(limitedVectorLeft);
        limitedVectorLeft.y = 0.0f;

        Debug.DrawRay(transform.position, limitedVectorLeft * 10, Color.red);
        Debug.DrawRay(transform.position, limitedVectorRight * 10, Color.red);
        Debug.DrawRay(transform.position, rb.velocity, Color.blue);
        float angle = Vector3.Angle(limitedVectorLeft, kayakvec);
        //Debug.Log("Angle: " + angle);

        return angle;


    }

    public float stopRotationWithVectorRight()
    {
        Vector3 kayakvec = transform.forward;
        Vector3 directionVector = DirectionVectorNormalize();

        Vector3 limitedVectorRight = Vector3.Cross(Vector3.up, directionVector);
        limitedVectorRight = Vector3.Normalize(limitedVectorRight);
        limitedVectorRight.y = 0.0f;

        Vector3 limitedVectorLeft = Vector3.Cross(Vector3.down, directionVector);
        limitedVectorLeft = Vector3.Normalize(limitedVectorLeft);
        limitedVectorLeft.y = 0.0f;

        Debug.DrawRay(transform.position, limitedVectorLeft * 10, Color.red);
        Debug.DrawRay(transform.position, limitedVectorRight * 10, Color.red);
        Debug.DrawRay(transform.position, rb.velocity, Color.blue);
        float angle = Vector3.Angle(limitedVectorRight, kayakvec);
        //Debug.Log("Angle: " + angle);

        return angle;


    }

}

