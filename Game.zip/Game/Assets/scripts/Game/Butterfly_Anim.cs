﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Butterfly_Anim : MonoBehaviour
{
    public string animName = "SButter_Flap_Anim";
    private Animator anim;

    void Start()
    {
        anim = GetComponent<Animator>();
        float wait = Random.value;
        Invoke("StartAnim", wait);
    }

    void StartAnim() {
        anim.Play(animName);
    }
}
