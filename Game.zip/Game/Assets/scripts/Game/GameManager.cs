﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;
using UnityEngine.SceneManagement;

using Audio;

public class GameManager : MonoBehaviour
{
    public Text txtPoints;
    public Text txtAddPoints;
    public Text txtGamePause;
    public string startScene;
    public GameObject monsterImg;
    public RectTransform rectTransKayak;
    public RectTransform pathLeftBottom;
    public RectTransform pathRightTop;
    public Transform portal;
    public SnapshotCamerea snapCam;
    public Canvas canvas;
    public RawImage _tutorial;
    public Animator animator;
    private Fade fade;
    public GameObject[] animDave;
    public Light[] lieVec;
    public float newLight;


    private Vector3 _startPoint;
    private float _dist = 0;
    private int _points = 0;
    private Kayak _kayak;
    private Follower _follower;
    private bool _bReset = false;
    private AudioManager _audioManager;

    private void Awake() {
        _kayak = FindObjectOfType<Kayak>();
        _follower = FindObjectOfType<Follower>();
        _audioManager = FindObjectOfType<AudioManager>();
        activatePoints(false);
        fade = FindObjectOfType<Fade>();
    }

    private void Start() {
        Udp_send.sendMessageToAll("running");
        _startPoint = _follower.transform.position;
        setMonsterMovement(false);
        PlayerData.setWinGame(false);
        txtAddPoints.text = "";
        _audioManager.CaveMusic();
        pauseGame(false, true, false);
    }

    private void changeLigtIntenc(float value) {
        foreach (Light lig in lieVec) {
            lig.intensity *= value;
            Debug.Log("Intencs: " + lig.intensity);
        }
    }

    void Update() {
        if (Input.GetKey("escape")) {
            exitGame();
        }
        if (Input.GetKey("space")) {
            resetGame();
        }
        if (Input.GetKey(KeyCode.S)) {
            setMonsterMovement(false);
        }
        if (Input.GetKey(KeyCode.W)) {
            setMonsterMovement(true);
        }
        if (Input.GetKey(KeyCode.T)) {
            pauseGame();
        }
        if (Input.GetKey(KeyCode.LeftShift) && Input.GetKey(KeyCode.T)) {
            pauseGame(false);
        }
        if (Input.GetKey(KeyCode.O)) {
            gameOver();
            //fade.StartFadeFinishGame();
        }
        if (Input.GetKeyDown(KeyCode.I)) {
            if(snapCam != null)
                snapCam.callTakeSnapshot();
        }
        if (Input.GetKey(KeyCode.G)) {
            SetGUI(false);
        }
        if (Input.GetKey(KeyCode.LeftShift) && Input.GetKey(KeyCode.G)) {
            SetGUI(true);
        }
        if(Input.GetKey(KeyCode.LeftShift) && Input.GetKey(KeyCode.F)){
            //fade.StartFadeOut();
           
        }

        updatePathImg();
    }

    public IEnumerator Animation()
    {
        yield return new WaitForSeconds(5);
    }

    public void setMonsterMovement(bool p_bMovement, bool p_bGUI = true)
    {
        if(p_bGUI)
            monsterImg.GetComponent<RawImage>().enabled = p_bMovement;
        else
            monsterImg.GetComponent<RawImage>().enabled = p_bGUI;

        _follower.setMonsterMove(p_bMovement);
        if (p_bMovement)
            _audioManager.SeaMonsterStart();
    }

    public void exitGame()
    {
        Application.Quit();
    }

    public void finishGame()
    {
        Debug.Log("Finish!");
        PlayerData.setScore(_points);
        PlayerData.setDistance(_dist);
        PlayerData.setWinGame(true);
        setMonsterMovement(false);
        Udp_send.sendMessageToAll("restart");
        fade.StartFadeFinishGame();
        Invoke("loadOutro", 2);
    }
    
    public void loadOutro() {
        SceneManager.LoadScene("Outro");
    }

    public void endGame()
    {
        Udp_send.sendMessageToAll("restart");
        //fade.StartFadeOut();
        SceneManager.LoadScene(startScene);
    }

    public void gameOver()
    {
        if (!_bReset)
        {
            _bReset = true;
            //fade.StartFadeOut();
            PlayerData.setWinGame(false);
            Udp_send.sendMessageToAll("restart");
            Debug.Log("Game Over!");
            fade.FadeToWhite();
            Invoke("loadGameOver", 1);
        }
    }
    public void loadGameOver() {
        SceneManager.LoadScene("Gameover");
    }
    public void resetGame()
    {
        _bReset = false;
        _kayak.resetPosition();
        _follower.resetPosition();
        _kayak.GetComponent<pathLine>().enabled = false;
    }

    public void getGlue() {
        txtPoints.enabled = true;
    }

    public void setDist(float dist)
    {
        if (dist < 0)
            _dist = 0;
        else
            _dist = dist;
    }

    public void setPoints(int points)
    {
        _points = points;
        txtPoints.text = _points.ToString("0000");
    }

    public void addPoints(int points)
    {
        _points += points;
        txtAddPoints.text = "+" + points.ToString("0");
        txtAddPoints.enabled = true;
        Invoke("disableAddPoints", 0.4f);
        txtPoints.text = _points.ToString("0000");
    }

    public void awakeDave() {
        activatePoints(true);
        foreach (GameObject obj in animDave) {
            obj.GetComponent<AwakDaveAnim>().daveAwake();
        }
        _audioManager.SeaMonsterAwake();
        _tutorial.gameObject.SetActive(false);
    }

    private void disableAddPoints()
    {
        txtAddPoints.enabled = false;
    }

    public void addForceToKayak(int side, float force, bool newHit = false, float soundForce = 1)
    {
        _kayak.addForce(side, force, newHit, soundForce);
    }


    public void pauseGame(bool pause = true, bool showTxt = true, bool sound = true) {
        if (sound)
            _audioManager.MenuAcknowledge();
        if (pause)
        {
            Time.timeScale = 0;
            Udp_send.sendMessageToAll("pause");
            _audioManager.StartPause();
            if(showTxt)
                txtGamePause.enabled = true;
            else
                txtGamePause.enabled = false;
        }
        else
        {
            Time.timeScale = 1;
            Udp_send.sendMessageToAll("running");
            _audioManager.EndPause();
            txtGamePause.enabled = false;
        }
    }
    public void activatePoints(bool p_bValue = true) {
        txtAddPoints.enabled = p_bValue;
        txtPoints.enabled = p_bValue;
    }

    private void updatePathImg() {
        float pathLength = pathRightTop.position.y - pathLeftBottom.position.y;
        float riverLength = Mathf.Abs(Vector3.Distance(portal.position, _startPoint));
        if (riverLength == 0)
            return;

        //pos of Kayak Img
        float kayakPos = Vector3.Distance(_kayak.transform.position, _startPoint);
        float kayakImgPosY = (kayakPos / riverLength) * pathLength + pathLeftBottom.position.y;
        Vector3 newKayakPos = new Vector3(rectTransKayak.position.x, kayakImgPosY, rectTransKayak.position.z);

        rectTransKayak.SetPositionAndRotation(newKayakPos, rectTransKayak.rotation);


        //pos of Monster Img
        RectTransform monsterRectMonster = monsterImg.GetComponent<RectTransform>();
        if (monsterRectMonster == null) {
            Debug.Log("Error while get moster image");
            return;
        }
        float monsterPos = Vector3.Distance(_follower.transform.position, _startPoint);
        float monsterImgPosY = (monsterPos / riverLength) * pathLength + pathLeftBottom.position.y;
        Vector3 newMonsterPos = new Vector3(monsterRectMonster.position.x, monsterImgPosY, monsterRectMonster.position.z);

        monsterRectMonster.SetPositionAndRotation(newMonsterPos, monsterRectMonster.rotation);
    }
    public void SetGUI(bool p_value) {
        canvas.enabled = p_value;
    }
}
   
