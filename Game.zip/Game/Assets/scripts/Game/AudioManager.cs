﻿using System.Collections.Generic;
using UnityEngine;

namespace Audio
{
    public class AudioManager : MonoBehaviour
    {
        public static AudioManager instance;

        [SerializeField]
        private Sound[] sounds;
        [SerializeField]
        private GameOverSound gameOver;
        [SerializeField]
        private SeeschlangeSound seaMonster;
        [SerializeField]
        private SeaMonsterLocalSound monsterGrumble;
        [SerializeField]
        private ExplosionSound explosion;
        [SerializeField]
        private RestartSound restart;
        private Dictionary<string, int> soundsIndex = new Dictionary<string, int>();

        private Coroutine[] coroutines = new Coroutine[4];

        private void Awake()
        {
            if (instance == null)
            {
                instance = this;
            }
            else if (instance != this)
            {
                Destroy(gameObject);
            }
        }

        // Start is called before the first frame update
        private void Start()
        {
            string name;

            for (int i = 0; i < sounds.Length; i++)
            {
                name = sounds[i].clipName;

                // fill dictionary once at startup
                soundsIndex.Add(name, i);
                //create gameobject for every sound
                GameObject _go = new GameObject("Sound_" + i + "_" + name);
                //set audiomanager as parent
                _go.transform.SetParent(this.transform);
                //add audio source to gameobject and set properties
                if (!sounds[i].SetAudioSource(_go.AddComponent<AudioSource>()))
                    Debug.Log("Error while set Sound_" + i + "_" + name);
            }
        }

        /// <summary>
        /// Play 2D-sound. Doesn't play if sound is already playing.
        /// </summary>
        /// <param name="index">Index of the sound to be played</param>
        private void Play(int index)
        {
            //play if not already playing
            if (!sounds[index].IsPlaying)
            {
                sounds[index].Play();
            }
        }

        /// <summary>
        /// Play 2D-sound. Doesn't play if sound is already playing.
        /// </summary>
        /// <param name="soundName">Name of the sound to be played</param>
        private void Play(string soundName)
        {
            int index;
            //look up index of given sound
            if (!soundsIndex.TryGetValue(soundName, out index))
            {
                Debug.LogWarning("Unable to play sound '"+ soundName +"': Sound not found.");
                return;
            }

            Play(index);
        }

        /// <summary>
        /// Stop playing sound.
        /// </summary>
        /// <param name="soundName">Name of the sound to be stopped playing</param>
        private void Stop(string soundName)
        {
            int index;
            //look up index of given sound
            if (!soundsIndex.TryGetValue(soundName, out index))
            {
                Debug.LogWarning("Unable to stop playing sound '" + soundName + "': Sound not found.");
                return;
            }

            sounds[index].Stop();
        }

        /// <summary>
        /// Pause playing sound.
        /// </summary>
        /// <param name="soundName">Name of the sound to be paused</param>
        /// <returns>Returns true if sound was paused. Otherwise false, especially when sound was not playing.</returns>
        private bool Pause(string soundName)
        {
            int index;
            //look up index of given sound
            if (!soundsIndex.TryGetValue(soundName, out index))
            {
                Debug.LogWarning("Unable to pause sound '" + soundName + "': Sound not found.");
                return false;
            }

            if (!sounds[index].IsPlaying)
                return false;

            sounds[index].Pause();
            return true;
        }

        /// <summary>
        /// Unpause sound.
        /// </summary>
        /// <param name="soundName">Name of the sound to be unpaused</param>
        private void UnPause(string soundName)
        {
            int index;
            //look up index of given sound
            if (!soundsIndex.TryGetValue(soundName, out index))
            {
                Debug.LogWarning("Unable to unpause sound '" + soundName + "': Sound not found.");
                return;
            }

            if (sounds[index].IsPlaying)
                return;

            sounds[index].UnPause();
        }

        /// <summary>
        /// Play sound on given position. Use for 3d sounds.
        /// </summary>
        /// <param name="index">Index of the sound to be played</param>
        /// <param name="position">Position from where sound originates</param>
        /// <param name="immediate">Stop sound if already playing and start playing from beginning</param>
        private void PlayPositioned(int index, Vector3 position, bool immediate = false)
        {
            //if not played imidiately abort if sound is already playing
            if (!immediate && sounds[index].IsPlaying)
                return;

            //change position of gameobject and play
            sounds[index].GameObject.transform.position = position;
            sounds[index].Play();
        }

        /// <summary>
        /// Play sound on given position. Use for 3d sounds.
        /// </summary>
        /// <param name="soundName">Name of the sound to be played</param>
        /// <param name="position">Position from where sound originates</param>
        /// <param name="immediate">Stop sound if already playing and start playing from beginning</param>
        private void PlayPositioned(string soundName, Vector3 position, bool immediate = false)
        {
            int index;
            //look up index of given sound
            if (!soundsIndex.TryGetValue(soundName, out index))
            {
                Debug.LogWarning("Unable to play sound '" + soundName + "': Sound not found.");
                return;
            }

            PlayPositioned(index,position,immediate);
        }

        /// <summary>
        /// Play sound overlapping on given position. Sets pitch ranging from pitch - pitchDeltaLower to pitch + pitchDeltaHigher. Use for 3d sounds.
        /// </summary>
        /// <param name="soundName">Name of the sound to be played</param>
        /// <param name="position">Position from where sound originates</param>
        /// <param name="pitchDeltaLower">Maximal lower deviation from pitch. Defaults to 0.</param>
        /// <param name="pitchDeltaHigher">Maximal lower deviation from pitch. Defaults to 0.</param>
        private void PlayPositionedOneShot(string soundName, Vector3 position, float pitchDeltaLower = 0, float pitchDeltaHigher = 0)
        {
            int index;
            //look up index of given sound
            if (!soundsIndex.TryGetValue(soundName, out index))
            {
                Debug.LogWarning("Unable to play sound '" + soundName + "': Sound not found.");
                return;
            }

            PlayPositionedOneShot(index, position, pitchDeltaLower, pitchDeltaHigher);
        }

        /// <summary>
        /// Play sound overlapping on given position. Sets pitch ranging from pitch - pitchDeltaLower to pitch + pitchDeltaHigher. Use for 3d sounds.
        /// </summary>
        /// <param name="index">Index of the sound to be played</param>
        /// <param name="position">Position from where sound originates</param>
        /// <param name="pitchDeltaLower">Maximal lower deviation from pitch. Defaults to 0.</param>
        /// <param name="pitchDeltaHigher">Maximal lower deviation from pitch. Defaults to 0.</param>
        private void PlayPositionedOneShot(int index, Vector3 position, float pitchDeltaLower = 0, float pitchDeltaHigher = 0)
        {
            if((pitchDeltaLower >= 0) && (pitchDeltaHigher >= 0))
            {
                float pitch = sounds[index].pitch + Random.Range(-pitchDeltaLower, pitchDeltaHigher);
                sounds[index].SetPitch(pitch);
            }

            //change position of gameobject and play
            sounds[index].GameObject.transform.position = position;
            sounds[index].PlayOneShot();
        }

        /// <summary>
        /// Play sound for paddle move through water
        /// </summary>
        /// <param name="transform">Transform representing the spatial source of the sound</param>
        /// <param name="force">Indicates duration of paddle movement in water. Between 0 (short) and 1 (long).</param>
        /// <param name="player">Represents the player that moves the paddle, e.g. 1 represents player 1. Default is 1.</param>
        public void Paddle(Transform transform, float force, int player = 1)
        {
            int index;
            int coroutine = player - 1;
            string soundName;

            switch (player)
            {
                case 1: soundName = "paddle_1";
                    break;
                case 2: soundName = "paddle_2";
                    break;
                case 3: soundName = "paddle_3";
                    break;
                case 4: soundName = "paddle_4";
                    break;
                default: soundName = "paddle_1";
                    break;
            }
            //look up index of sound
            if (!soundsIndex.TryGetValue(soundName, out index))
            {
                Debug.LogWarning("Unable to play sound '" + soundName + "': Sound not found.");
                return;
            }

            float p = 1.8f - force + Random.Range(-0.05f, 0.05f);

            float fadeTime = 0.8f + (force + Random.Range(0f, 0.2f)) / 1.2f * 1.2f;

            sounds[index].SetPitch(p);
            if (coroutines[coroutine] != null)
            {
                StopCoroutine(coroutines[coroutine]);
            }
            //set volume in case coroutine was stopped
            sounds[index].SetVolume(sounds[index].InitialVolume);
            sounds[index].SetParentTransform(transform);
            PlayPositionedOneShot(index, transform.position);
            coroutines[coroutine] = StartCoroutine(sounds[index].FadeOut(fadeTime));
        }

        /// <summary>
        /// Play sound for collecting a glod coin as 2D-sound
        /// </summary>
        public void CollectCoinGold()
        {
            Play("collect_coin_big");
        }

        /// <summary>
        /// Play sound for collecting a silver coin as 2D-sound
        /// </summary>
        public void CollectCoinSilver()
        {
            Play("collect_coin_small");
        }

        /// <summary>
        /// Play sound for collecting stuff e.g. nail or glasses (except glue and clock) as 2D-sound
        /// </summary>
        public void CollectStuff()
        {
            Play("collect_stuff");
        }

        /// <summary>
        /// Play 2D-sound for collecting a clock
        /// </summary>
        public void CollectClock()
        {
            Play("collect_rewind");
        }

        /// <summary>
        /// Play 2D-sound for collecting the holy glue
        /// </summary>
        public void CollectGlue()
        {
            Play("collect_glue");
        }

        /// <summary>
        /// Play sound for collision of kayak with rock like material
        /// </summary>
        /// <param name="position">Position from where sound originates</param>
        public void CollisionRock(Vector3 position)
        {
            string soundName;

            soundName = (Random.Range(1, 3) == 1) ? "collision_rock_1" : "collision_rock_2";

            int index;

            if (!soundsIndex.TryGetValue(soundName, out index))
            {
                Debug.LogWarning("Unable to play sound '" + soundName + "': Sound not found.");
                return;
            }


            PlayPositionedOneShot(index, position, 0.07f, 0.01f);
        }

        /// <summary>
        /// Play sound for collision of kayak with wood like material
        /// </summary>
        /// <param name="position">Position from where sound originates</param>
        public void CollisionWood(Vector3 position)
        {
            PlayPositionedOneShot("collision_wood", position);
        }

        /// <summary>
        /// Play sound when game over is displayed.
        /// </summary>
        public void GameOver()
        {
            if (gameOver == null)
            {
                Debug.LogWarning("Unable to play game over sound: missing object reference.");
                return;
            }
            gameOver.Play();
        }

        /// <summary>
        /// Play sound when kayak hits sea monster.
        /// </summary>
        /// /// <param name="position">Position from where sound originates</param>
        public void CollisionSeaMonster(Vector3 position)
        {
            if (monsterGrumble == null)
            {
                Debug.LogWarning("Unable to play monster grumble sound: missing object reference.");
                return;
            }

            monsterGrumble.PlayGrumble();

            int index;

            if (!soundsIndex.TryGetValue("collision_sea_monster", out index))
            {
                Debug.LogWarning("Unable to play sound 'collision_sea_monster': Sound not found.");
                return;
            }

            PlayPositionedOneShot(index, position, 0.05f, 0.05f);
        }

        /// <summary>
        /// Play sound when sea monster moves after collecting the holy glue.
        /// </summary>
        public void SeaMonsterAwake()
        {
            if (monsterGrumble == null)
            {
                Debug.LogWarning("Unable to play monster awaking sound: missing object reference.");
                return;
            }

            monsterGrumble.PlayQuake();
            monsterGrumble.PlayMoveWater();
        }

        /// <summary>
        /// Play sound when cave entry explodes.
        /// </summary>
        private void Explode()
        {
            if (explosion == null)
            {
                Debug.LogWarning("Unable to play explosion sound: missing object reference.");
                return;
            }
            explosion.Play();
        }


        private void SeaMonsterSounds()
        {
            if (seaMonster == null)
            {
                Debug.LogWarning("Unable to play seamonster sound: missing object reference.");
                return;
            }

            seaMonster.PlayNoise();
            seaMonster.PlayScream();
            seaMonster.PlayHeartBeat();
        }

        /// <summary>
        /// Play sounds when sea monster starts to follow player. Sounds loop. No further calls necessary.  
        /// </summary>
        public void SeaMonsterStart()
        {
            if (seaMonster == null)
            {
                Debug.LogWarning("Unable to play seamonster sound: missing object reference.");
                return;
            }

            int index;
            //look up index of sound
            if (!soundsIndex.TryGetValue("route_music", out index))
            {
                Debug.LogWarning("Unable to play pursuit music: Music not found.");
                return;
            }

            SeaMonsterSounds();
            Stop("cave_music");
            Play(index);
            StartCoroutine(sounds[index].FadeIn(1.1f));
            // wait 2 seconds before playing explosion sound
            Invoke("Explode", 2f);
        }

         /// <summary>
        /// Play single sea monster scream. Overlaps with other seamonster sounds.
        /// </summary>
        public void SeaMonsterScreech()
        {
            if (seaMonster == null)
            {
                Debug.LogWarning("Unable to play seamonster sound: missing object reference.");
                return;
            }
            seaMonster.PlayScreechOneShot();
        }

        /// <summary>
        /// Play sound for actions like ok, right and confirming a choice (think of the a-key). Call before executing the action.
        /// </summary>
        public void MenuAcknowledge()
        {
            Play("menu_agree");
        }

        /// <summary>
        /// Play sound for actions like back, cancel and pause (think of the b-key). Call before executing the action.  
        /// </summary>
        public void MenuDecline()
        {
            Play("menu_back");
        }

        /// <summary>
        /// Play sound when user is in the menu and hits the start playing-button. Call before actually starting the game.
        /// </summary>
        public void MenuStart()
        {
            Play("menu_start");
        }

        /// <summary>
        /// Play sound when user registered to play and appears on screen.
        /// </summary>
        public void MenuPlayerRegistered()
        {
            Play("menu_registered");
        }

        /// <summary>
        /// Play sound when restart button gets activated. Call before changing scene.
        /// </summary>
        public void RestartGame()
        {
            if(restart == null)
            {
                Debug.LogWarning("Unable to play restart sound: missing object reference.");
                return;
            }
            restart.Play();
        }

        /// <summary>
        /// Play sound when highscore appears.
        /// </summary>
        public void Highscore()
        {
            Play("highscore");
        }

        /// <summary>
        /// Play sound when score calculation is displayed.
        /// </summary>
        public void HighscoreScore()
        {
            Play("highscore_score");
        }

        /// <summary>
        /// Play sound when player gets ranked in highscore.
        /// </summary>
        public void HighscoreRank()
        {
            Play("highscore_rank");
        }
        
        /// <summary>
        /// Play sound when tree is about to start falling. 
        /// </summary>
        /// <param name="position">Position from where sound originates</param>
        public void TreeFall(Vector3 position)
        {
            PlayPositionedOneShot("tree_fall", position);
        }

        /// <summary>
        /// Play sound when tree hits the water. Also stops playing the sound for the tree falling.
        /// </summary>
        /// <param name="position">Position from where sound originates</param>
        public void TreeSplash(Vector3 position)
        {
            Stop("tree_fall");
            PlayPositionedOneShot("tree_splash", position);
        }

        /// <summary>
        /// Play sound when kayak moves through grass.
        /// </summary>
        /// <param name="position">Position from where sound originates</param>
        public void Grass(Vector3 position)
        {
            PlayPositionedOneShot("collision_grass", position);
        }

        /// <summary>
        /// Play music while staying in the menu. Not supposed to be used for the highscore. 
        /// </summary>
        public void StartMenu()
        {
            Play("menu_music");
        }

        /// <summary>
        /// Stop playing the menu music
        /// </summary>
        public void StopMenu()
        {
            Stop("menu_music");
        }

        /// <summary>
        /// Pause background music. Call when player pauses the game.
        /// </summary>
        public void StartPause()
        {
            AudioListener.pause = true;
        }

        /// <summary>
        /// Continue playing background music. Call when player resumes playing.
        /// </summary>
        public void EndPause()
        {
            AudioListener.pause = false;
        }

        /// <summary>
        /// Play general beep sound for countdown. Not used for final beep -> use CountdownFinalBeep().   
        /// </summary>
        public void CountdownGeneralBeep()
        {
            Play("countdown_low");
        }

        /// <summary>
        /// Play final countdown beep sound. Use for last beep before game starts.
        /// </summary>
        public void CountdownFinalBeep()
        {
            Play("countdown_high");
        }

        /// <summary>
        /// Start playing background music of cave area. Sound fades in and loops. 
        /// </summary>
        public void CaveMusic()
        {
            int index;
            //look up index of sound
            if (!soundsIndex.TryGetValue("cave_music", out index))
            {
                Debug.LogWarning("Unable to play cave music: Music not found.");
                return;
            }

            Play(index);
            StartCoroutine(sounds[index].FadeIn(1.0f));
        }

        /// <summary>
        /// Start playing sound when highscore points get accumulated.
        /// </summary>
        public void StartPointsTally()
        {
            Play("highscore_score");
        }

        /// <summary>
        /// Stop playing highscore accumulation sound. 
        /// </summary>
        public void StopPointsTally()
        {
            Stop("highscore_score");
        }

        /// <summary>
        /// Play sound of a crow calling.
        /// </summary>
        /// <param name="position">Position from where sound originates</param>
        public void Crow(Vector3 position)
        {
            string soundName;

            soundName = (Random.Range(1, 3) == 1) ? "crow1" : "crow2";

            PlayPositionedOneShot(soundName, position);
        }
    }
}