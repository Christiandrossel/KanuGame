﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class LowPolyPortal : MonoBehaviour
{
    public float power = 3;
    public float scale = 1;
    public float timeScale = 1;

    //public Transform WaveOrigin;

    private float offsetX;
    private float offsetZ;
    private Vector3 origin;

    private MeshFilter mf;
    private Mesh startMesh;


    void Awake() {
        mf = GetComponent<MeshFilter>();
        makeNoise();
    }
    
    public void Update() {
        makeNoise();
        offsetX += Time.deltaTime * timeScale;
        offsetZ += Time.deltaTime * timeScale;
    }

    private void makeNoise() {
        Vector3[] verticies = mf.mesh.vertices;

        for (int i = 0; i < verticies.Length; i++) {
            verticies[i].y = calculateHeight(verticies[i].x, verticies[i].z) * power;
        }
        mf.mesh.vertices = verticies;
    }

    private float calculateHeight(float x, float z) {
        float xCord = x * scale + offsetX;
        float zCord = z * scale + offsetZ;

        return Mathf.PerlinNoise(xCord, zCord);
    }

    private float calculateYfromSin(float x, float z) {
        float dist = Mathf.Sqrt((x * origin.x) + (z * origin.z));

        return Mathf.Sin(dist + Time.realtimeSinceStartup * timeScale);
    }
}