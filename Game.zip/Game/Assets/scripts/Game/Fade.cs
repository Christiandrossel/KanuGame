﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Fade : MonoBehaviour
{
    private Animator animator;
    public int levelToLoad;
    private bool switching;
    private float timer = 1;

    private void Update()
    {
        if (switching)
        {
            //animator.Play("Fade_out");
            //timer = timer - Time.deltaTime;
            //Debug.Log("Timer: " + timer);
            //if(timer <= 0)
            //{
            //    switching = false;
            //    timer = 1;
            //}
        }
       
    }
 
    public void Start()
    {
        animator = GetComponent<Animator>();
    }

    public void FadeToLevel(int levelIndex)
    {
        levelToLoad = levelIndex;
        animator.SetTrigger("FadeOut");
    }

    public void StartFadeOut()
    {
        //switching = true;
        animator.SetTrigger("FadeOut");
        Debug.Log("StartFadeOut()");
    }

    public void OnFadeComplete()
    {
        SceneManager.LoadScene(levelToLoad);
    }

    public void FadeToWhite(){
        animator.Play("Fade_Out_white");           
    }

    public bool StartFadeFinishGame()
    {
        animator.SetBool("FadeOutPortal", true);
        while (!(timer <= 0))
        {
            animator.Play("FadeOutPortal");
            timer = timer - Time.deltaTime;
            Debug.Log("Timer: " + timer);
            if (timer <= 0)
            {
                switching = false;
                timer = 1;
                return true;
            }
        }
        return true;
    }
}
