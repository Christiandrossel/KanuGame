﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class move_cam: MonoBehaviour
{
    public GameObject kayak;
    public float rotSmoothSpeed = 0.125f;
    public Transform camPos;

    private float distKayakNoY = 0;
    private float distKayakY = 0;

    void Start(){
        camPos.position = transform.position - kayak.transform.position;
        Vector3 vec = (transform.position - kayak.transform.position);
        distKayakY = vec.y;
        //Debug.Log(vec+"_Y: "+distKayakY+"__noY: "+distKayakNoY);
        vec.y = 0;
        distKayakNoY = vec.magnitude;
    }
    
    void FixedUpdate()
    {
        //Debug.Log(camPos.position + " - " + kayak.transform.position + " = " + Vector3.Distance(camPos.position, kayak.transform.position));

        //smooth rotation
        Quaternion newRotation = Quaternion.Slerp(transform.rotation, kayak.transform.rotation, rotSmoothSpeed * Time.deltaTime);

        transform.rotation = Quaternion.Euler(transform.rotation.eulerAngles.x, newRotation.eulerAngles.y, newRotation.eulerAngles.z);

        //set position of Cam fix
        Vector3 pos = kayak.transform.forward;
        pos *= distKayakNoY;
        pos.y += distKayakY;
        //Debug.Log(pos);
        transform.position = kayak.transform.position + pos;
    }
}