﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Colectable : MonoBehaviour
{
    public float _rotSpeed = 140;
    
    void Update()
    {
        transform.Rotate(Vector3.up, _rotSpeed * Time.deltaTime, Space.World);
    }
}
