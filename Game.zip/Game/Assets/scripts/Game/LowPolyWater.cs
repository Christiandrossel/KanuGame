﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class LowPolyWater : MonoBehaviour
{

    public float size = 1;
    public int gridSize = 16;

    public float power = 3;
    public float scale = 1;
    public float timeScale = 1;

    //public Transform WaveOrigin;

    private float offsetX;
    private float offsetZ;
    private Vector3 origin;

    private MeshFilter mf;
    private Mesh startMesh;


    void Start()
    {
        mf = GetComponent<MeshFilter>();
        makeNoise();
    }
    
    Mesh makeLowPolyMesh()
    {
        Mesh m = new Mesh();

        var verts = new List<Vector3>();
        var norms = new List<Vector3>();
        var uvs = new List<Vector2>();

        for (int x = 0; x <= gridSize; x++)
        {
            for(int z = 0; z <= gridSize; z++)
            {
                verts.Add(new Vector3(-size * 0.5f +size * (x / (float)gridSize), 0, -size * 0.5f + size * (z / (float)gridSize)));
                norms.Add(Vector3.up);
                uvs.Add(new Vector2(x / (float)gridSize, z / (float)gridSize));
            }
        }

        var triangles = new List<int>();
        var vertCount = gridSize + 1;

        for(int i = 0; i < vertCount * vertCount - vertCount; i++)
        {
            if ((i + 1) % vertCount == 0)
                continue;
            triangles.AddRange(new List<int>(){
                i+1+vertCount, i+vertCount, i,
                i, i+1, i+vertCount+1
            });
        }

        m.SetVertices(verts);
        m.SetNormals(norms);
        m.SetUVs(0, uvs);
        m.SetTriangles(triangles, 0);
        return m;
    }

    public void Update()
    {
        makeNoise();
        offsetX += Time.deltaTime * timeScale;
        offsetZ += Time.deltaTime * timeScale;
    }

    private void makeNoise()
    {
        Vector3[] verticies = mf.mesh.vertices;

        for (int i = 0; i <verticies.Length; i++)
        {
            verticies[i].y = calculateHeight(verticies[i].x, verticies[i].z) * power;
        }
        mf.mesh.vertices = verticies;
    }

    private float calculateHeight(float x, float z)
    {
        float xCord = x * scale + offsetX;
        float zCord = z * scale + offsetZ;

        return Mathf.PerlinNoise(xCord, zCord);
    }
    
    private float calculateYfromSin(float x, float z)
    {
        float dist = Mathf.Sqrt((x * origin.x) + (z * origin.z));

        return Mathf.Sin(dist + Time.realtimeSinceStartup * timeScale);
    }
}