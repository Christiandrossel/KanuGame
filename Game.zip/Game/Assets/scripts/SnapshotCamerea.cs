﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using System;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

[RequireComponent(typeof(Camera))]
public class SnapshotCamerea : MonoBehaviour
{
    Camera snapCam;
    int resWidth = 256;
    int resHeight = 256;

    void Awake(){
        snapCam = GetComponent<Camera>();
        if (snapCam.targetTexture == null) {
            snapCam.targetTexture = new RenderTexture(resWidth, resHeight, 24);
        } else {
            resHeight = snapCam.targetTexture.height;
            resWidth = snapCam.targetTexture.width;
        }
        snapCam.gameObject.SetActive(false);
    }
    
    public void callTakeSnapshot() {
        snapCam.gameObject.SetActive(true);
    }

    private void LateUpdate() {
        if (snapCam.gameObject.activeInHierarchy) {
            Texture2D snapshot = new Texture2D(resWidth, resHeight, TextureFormat.RGB24, false);
            snapCam.Render();
            RenderTexture.active = snapCam.targetTexture;
            snapshot.ReadPixels(new Rect(0, 0, resWidth, resHeight), 0, 0);
            byte[] bytes = snapshot.EncodeToPNG();
            string fileName = SnapshotName();
            System.IO.File.WriteAllBytes(fileName, bytes);
            Debug.Log("Aufnahmen gespeichert unter '" + fileName+"'");
            snapCam.gameObject.SetActive(false);
        }
    }
    private string SnapshotName() {
        if (!Directory.Exists(Application.dataPath + "/Aufnahmen")) {
            Directory.CreateDirectory(Application.dataPath + "/Aufnahmen");
        }
        return string.Format("{0}/Aufnahmen/aufnahme_{1}x{2}_{3}.png",
            Application.dataPath,
            resWidth, resHeight,
            System.DateTime.Now.ToString("yyyy-MM-dd-HH-mm-ss"));
    }

}
