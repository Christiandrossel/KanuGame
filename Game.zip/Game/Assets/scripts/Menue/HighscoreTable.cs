﻿using System.Collections;
using System.Collections.Generic;
using System.Xml;
using System.Xml.Linq;
using System.Xml.Serialization;
using UnityEngine;
using UnityEngine.UI;
using System;
using System.Linq;

public class HighscoreTable : MonoBehaviour
{
    public Transform entryContainer;
    public Transform entryTemplate;

    public Transform rankContainer;
    public Transform rankTemplate;
    
    public bool ButtonActive;

    private int numberOfUser;
    private bool showTheWinner;
    private bool winGame = false;
    private UserListManager myUserListManager;


    private void Awake() {

        //for tests
        /*******************************************************************************************************************************************************************/

        //PlayerData.addPlayer("Jo_26", "135", "sd6", "not ready");
        //PlayerData.setDistance(50);
        //PlayerData.setFinalScore(1554);
        //PlayerData.setWinGame(true);

        /*******************************************************************************************************************************************************************/
        
        winGame = PlayerData.getWinGame();
        entryTemplate.gameObject.SetActive(false);                                          //Vordef. Textfelder für Platz, Name, Punkte deaktivieren

        /*User Liste wird erstellt in dem alle User verwaltet werden*/
        myUserListManager = new UserListManager();
        //myUserListManager.deleteAll();
        
        //PlayerPrefs.DeleteAll();
        //myUserListManager.generatingUserDummys();
        myUserListManager.loadUser();                                                       //Lade User aus den Player Prefs

        // add new User
        if (winGame)
        {
            if (PlayerData.getFinalScore() > 0 && !String.IsNullOrEmpty(PlayerData.getAllNameString()))
            {
                myUserListManager.setNewUser(PlayerData.getAllNameString(), PlayerData.getFinalScore());
            }
        }
        myUserListManager.sortUser();                                                       //Sortiere User (absteigend)
        //myUserListManager.getoutUserData();                                                 //Gibt aktuelle User auf der Konsole aus
        /* 
         * Wenn Button gedrückt wird, werden UserDummy Daten (10 stück) in die PlayerPrefs geschrieben
         * Und und die User Liste mit eingetragen 
         */                                                             //Anzeige der User die dem Spiel beitreten
        //button.onClick.AddListener(myUserListManager.generatingUserDummys);
        //button.gameObject.SetActive(ButtonActive);

        Debug.Log("PlayerDate.WinGame(): " + winGame);
        
        numberOfUser = myUserListManager.UserList.Count;                                   //Anzahl der User
        showTheWinner = true;
        int numberOfWinner = 0, winnerId = 0;
        int counter = 0;
        if (numberOfUser >= 1)
        {
            if (numberOfUser >= 10)
            {
                counter = 10;
            }
            else
                counter = 0;

            //Game.setWinGame(true);
            float templateHeight = 32f;
            float winOffset = 0f;
            for (int i = 0; i < counter; i++)
            {
                Transform entryTransform = Instantiate(entryTemplate, entryContainer);              //erzeuge eine neue Transform und setzte die in die Template und Container in die Transorm
                RectTransform entryRectTransform = entryTransform.GetComponent<RectTransform>();
                entryRectTransform.anchoredPosition = new Vector2(0, -templateHeight * i - winOffset);          //setze das neue Objekt an die Position...
                entryTransform.gameObject.SetActive(true);                                          //Mach das neue Objekt (Platz, Name) sichtbar
                

                //************************Anzeigen der PlayerPrefs Daten**********************************//
                entryTransform.Find("scoreText").GetComponent<Text>().text = myUserListManager.UserList[i].score.ToString();
                entryTransform.Find("nameText").GetComponent<Text>().text = myUserListManager.UserList[i].name;


                //Wenn User in den Top Ten ist
                /*Vergleiche Letzten User mit User Anzahl aus Liste und setze ein FontStyle Fett ein um Aktuellen User hervor zuheben*/
                if (myUserListManager.UserList[i].id == myUserListManager.UserList.Count && winGame)
                {
                    numberOfWinner = i;
                    winnerId = myUserListManager.UserList[i].id;
                    entryTransform.Find("nameText").GetComponent<Text>().fontStyle = FontStyle.Bold;
                    entryTransform.Find("scoreText").GetComponent<Text>().fontStyle = FontStyle.Bold;
                    entryTransform.Find("nameText").GetComponent<Text>().fontSize = 30;
                    entryTransform.Find("scoreText").GetComponent<Text>().fontSize = 30;
                    winGame = false;
                    Debug.Log("Winner is: " + myUserListManager.UserList[i].id);
                    showTheWinner = false;
                    winOffset = 10f;
                }
                //Wenn User nicht in topTen ist
                //ist das der letzte platz in der Liste
                if ((i == 9) && winGame)
                {
                    //ist der Letzte User und damit User Anzahl größer 10
                    if ((myUserListManager.UserList.Count > 10) && showTheWinner)
                    {
                        //setze die Daten des Aktuellen und damit letzten User aus der Liste in das Feld
                        Debug.Log("NumberOfUser: " + numberOfUser + " UserListID: " + myUserListManager.UserList[numberOfUser - 1].id);
                        numberOfWinner = i;
                        winnerId = myUserListManager.UserList[numberOfUser - 1].id;
                        
                        entryTransform.Find("scoreText").GetComponent<Text>().text = myUserListManager.UserList[numberOfUser - 1].score.ToString();
                        entryTransform.Find("nameText").GetComponent<Text>().text = myUserListManager.UserList[numberOfUser - 1].name;
                        
                        entryTransform.Find("nameText").GetComponent<Text>().fontStyle = FontStyle.Bold;
                        entryTransform.Find("scoreText").GetComponent<Text>().fontStyle = FontStyle.Bold;
                        
                        entryTransform.Find("nameText").GetComponent<Text>().fontSize = 30;
                        entryTransform.Find("scoreText").GetComponent<Text>().fontSize = 30;

                        showTheWinner = false;
                        winOffset = 10f;
                        break;
                    }
                }
            }
        }
        else
        {
            showNumberOfRank();
        }
        showNumberOfRank(numberOfWinner, winnerId);
    }

    //public int userrank()
    //{
    //    int rank;
    //    for(int i=1; i < )
    //    return rank;
    //}

    public void showNumberOfRank(int numberOfWinner , int winnerId)
    {
        int rank;
        int winRank = 0;
        float winOffset = 0;
        bool drawWinner = false;
        rankTemplate.gameObject.SetActive(false);

        for(int j = 0; j < myUserListManager.UserList.Count; j ++) {
            if (myUserListManager.UserList[j].id == winnerId)
                winRank = j + 1;
        }
        for (int i = 0; i < 10; i++)
        {                                    //Mach das neue Objekt (Platz, Name, Punkte) sichtbar
            rank = i + 1;
            Transform entryTransform = Instantiate(rankTemplate, rankContainer);              //erzeuge eine neue Transform und setzte die in die Template und Container in die Transorm
            RectTransform entryRectTransform = entryTransform.GetComponent<RectTransform>();
            entryRectTransform.anchoredPosition = new Vector2(0, -32f * i - winOffset);          //setze das neue Objekt an die Position...
            entryTransform.gameObject.SetActive(true);      
            
            if ((rank == winRank) && !drawWinner) {
                entryTransform.Find("posText").GetComponent<Text>().fontStyle = FontStyle.Bold;
                entryTransform.Find("posText").GetComponent<Text>().fontSize = 30;
                winOffset = 10f;
                rank = winRank;
                drawWinner = true;
            }
            entryTransform.Find("posText").GetComponent<Text>().text = rank.ToString();
        }
    }

    public void showNumberOfRank()
    {
        int rank;
        rankTemplate.gameObject.SetActive(false);
        for (int i = 0; i < 10; i++)
        {
            Transform entryTransform = Instantiate(rankTemplate, rankContainer);              //erzeuge eine neue Transform und setzte die in die Template und Container in die Transorm
            RectTransform entryRectTransform = entryTransform.GetComponent<RectTransform>();
            entryRectTransform.anchoredPosition = new Vector2(0, -32f * i);          //setze das neue Objekt an die Position...
            entryTransform.gameObject.SetActive(true);                                          //Mach das neue Objekt (Platz, Name, Punkte) sichtbar
            rank = i + 1;
            entryTransform.Find("posText").GetComponent<Text>().text = rank.ToString();
        }
    }
}
   
class User
{
    public string name { get; set; }
    public int score { get; set; }
    public int id { get; set; }
    public static int countUsers;

    public User(string name, int score, int id)
    {
        setUserData(name, score, id);
    }

    public void username(string name)
    {
        this.name = name;
    }
        
    public void setUserData(string name, int score, int id)
    {
        this.name = name;
        this.score = score;
        this.id = id;
        countUsers++;
        setIntoPlayPrefs();
    }

    public void setIntoPlayPrefs()
    {
        PlayerPrefs.SetString("user_name_"+id, name);
        PlayerPrefs.SetInt("user_" + id, id);
        PlayerPrefs.SetInt("user_score_"+id, score);
        PlayerPrefs.SetInt("UserCounter", countUsers);
    }

    public void deleteUser()
    {
        //PlayerPrefs.DeleteKey(string key)
    }
}
// https://docs.microsoft.com/de-de/dotnet/api/system.collections.generic.list-1.add?view=netframework-4.7.2
class UserListManager
{
    public List<User> UserList = new List<User>();
    public static int counter;

    public void setNewUser(string userName, int score)
    {
        if ((!String.IsNullOrEmpty(userName)) || (score!=0))
        {
            UserList.Add(new User(userName.ToUpper(), score, UserList.Count + 1));
            sortUser();
        }
        else
            Debug.Log("Error: Kein Usernamen bekommen");
    }

    public void setNewUser(string[] UserName, int score)
    {
        if ((String.IsNullOrEmpty(UserName[0])) || (UserName.Length == 0) || (score == 0))
        {
            Debug.Log("Error: keine Usernamen");
        }
        else
        {
            string user=UserName[0];
            for(int i=1; i < UserName.Length; i++)
            {
                user += " + " + UserName[i];
            }
            setNewUser(user, score);
        }
    }

    public int numberOfUser()
    {
        return (PlayerPrefs.GetInt("UserCounter"));
    }

    public void getRankScore(int UserID){}

    public void loadUser(int number)
    {
        string name;
        int id, score;
        for(int i = 0; i <= number; i++)
        {
            if (PlayerPrefs.HasKey("user_" + i))
            {
                score=PlayerPrefs.GetInt("user_score_"+i);
                name=PlayerPrefs.GetString("user_name_" + i);
                id=PlayerPrefs.GetInt("user_" + i);
                UserList.Add(new User(name, score, id));
                counter++;
            }
        }
    }

    public void loadUser()
    {
        string name;
        int id, score, number;
        number = numberOfUser();
        UserList.Clear();
        counter = 0;
        for (int i = 0; i <= number; i++)
        {
            if (PlayerPrefs.HasKey("user_" + i))
            {
                score = PlayerPrefs.GetInt("user_score_" + i);
                name = PlayerPrefs.GetString("user_name_" + i);
                id = PlayerPrefs.GetInt("user_" + i);
                UserList.Add(new User(name, score, id));
                counter++;
            }
        }
        Debug.Log("User: counter: " + counter + " ListCounter: " + UserList.Count);
    }

    public void sortUser()
    {
        UserList = UserList.OrderByDescending(User => User.score).ToList();
    }

    public void generatingUserDummys()
    {
        string[] Name = { "MARY", "BETTY", "GEORG", "BRIAN", "JASON", "GARY", "DAVID", "ANN", "ROSE", "ADAM", "HANS", "GUSTAV" };
        int[] Score = { 550, 320, 500, 150, 400, 350, 355, 300, 250, 200, 450, 50};
        int[] id = { 01, 02, 03, 04, 05, 06, 07, 08, 09, 10, 11, 12 };

        for (int i = 0; i < Name.Length; i++)
        {
            UserList.Add(new User(Name[i], Score[i], id[i]));
            counter++;
        }
        Debug.Log("User Dummy erstellt");
                        
    }

    public void getoutUserData()
    {
        if((UserList != null) || (UserList.Count != 0))
        {
            foreach(var user in UserList)
            {
                Debug.Log(user.name + " " + user.score + " " +user.id);
                
            }
            Debug.Log("Counter: " + counter);
        }
    }

    public string getLastUserName()
    {
        return UserList[UserList.Count].name;
    }

    public void deleteAll()
    {
        PlayerPrefs.DeleteAll();
        UserList.Clear();
        counter = 0;
        Debug.Log("Alle Daten gelöscht!");
    }
}