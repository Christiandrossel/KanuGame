﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using Audio;

public class GameManager_Menue : MonoBehaviour
{
    public GameObject _tableView;
    public GameObject _playerView;
    public GameObject _maintitleView;
    public AudioManager _audioManager;
    public Text[] _userText;
    public Text[] _readyText;
    public Text countdown = null;

    private float _timer = 0;
    private float _timerMax = 0;
    private bool _gameStarted = false;
    private int _count = 4;

    private HighscoreTable table;


    void Awake(){
        table = FindObjectOfType<HighscoreTable>();
        _audioManager = FindObjectOfType<AudioManager>();
    }
    private void Start() {
        updateUserText(true);
        PlayerData.resetData();
    }
    void Update(){

        if (Input.GetKey("escape")) {
            exitGame();
        }
        if (PlayerData.allReady() && !_gameStarted) {
            if (!Waited(1)) return;
            _timer = 0;
            _count--;
            countdown.text = _count.ToString();
            if (_count == 0) {
                _audioManager.CountdownFinalBeep();
                _gameStarted = true;
                startGame();
                //Invoke("startGame", 1f);
            } else {
                _audioManager.CountdownGeneralBeep();
            }
        }else {
            _timer = 0;
            _count = 4;
            countdown.text = "".ToString();
        } 
    }
    
    private bool Waited(float seconds)
    {
        _timerMax = seconds;
        _timer += Time.deltaTime;
        if (_timer >= _timerMax)
        {
            return true;
        }
        return false;
    }

    public void startGame(bool p_bButtonPress) {
        if (!p_bButtonPress)
            return;
        Udp_send.sendMessageToAll("running");
        SceneManager.LoadScene("Intro");
    }

    public void startGame() {
        if (!PlayerData.allReady())
            return;
        Udp_send.sendMessageToAll("running");
        SceneManager.LoadScene("Intro");
    }
    public void updateUserText(bool firstCall = false) {
        //ScoreTable
        if (PlayerData.getWinGame()) {
            _tableView.SetActive(true);
            _playerView.SetActive(false);
            _maintitleView.SetActive(false);
            _audioManager.StopMenu();
            _audioManager.Highscore();
            return;
        }

        //Main-Sreen
        if (PlayerData.getCount() == 0 || firstCall){
            _tableView.SetActive(false);
            _playerView.SetActive(false);
            _maintitleView.SetActive(true);
            _audioManager.StartMenu();
            return;
        }   

        //PlayerView
        _tableView.SetActive(false);
        _playerView.SetActive(true);
        _maintitleView.SetActive(false);
        _audioManager.StartMenu();

        for (int i = 0; i < _userText.Length; i++) {
            string name = PlayerData.getNameByIndex(i);
            _userText[i].text = (i + 1).ToString() + ". " + name;

            if (i >= PlayerData.getCount()) {
                _readyText[i].enabled = false;
                continue;
            }

            _readyText[i].enabled = true;
                        
            if (PlayerData.getStateByIndex(i) == "ready"){
                _readyText[i].text = "BEREIT";
            }
            else{
                _readyText[i].text = "NICHT BEREIT";
            }
        }
    }

    public void exitGame() {
        Application.Quit();
    }
}
