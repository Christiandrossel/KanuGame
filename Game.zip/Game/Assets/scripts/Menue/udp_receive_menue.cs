﻿/*
    -----------------------
    UDP-Receive (send to)
    -----------------------
    // [url]http://msdn.microsoft.com/de-de/library/bb979228.aspx#ID0E3BAC[/url]
   
   
    // > receive
    // 127.0.0.1 : 8051
   
    // send
    // nc -u 127.0.0.1 8052
 
*/

using System.Collections;
using System.Collections.Generic;
using System;
using UnityEngine;
using UnityEngine.UI;

using System.Text;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using Audio;

public class udp_receive_menue : MonoBehaviour
{
    // receiving Thread
    Thread receiveThread;

    // udpclient object
    UdpClient client;

    // public
    // public string IP = "127.0.0.1"; default local
    public int port = 8051; // define > init

    private GameManager_Menue _gameManager;
    private bool threatRunning = true;
    
    //flag for recive reactions
    private bool bUpdateUser = false;
    private bool bUserRegister = false;
    private bool bMenuAcknowledge = false;
    private bool bPlayerReady = false;
    private AudioManager _audioManager;

    private void Awake()
    {
        _gameManager = FindObjectOfType<GameManager_Menue>();
        _audioManager = FindObjectOfType<AudioManager>();
        init();
    }
    
    // init
    private void init()
    {
        //Text initialisieren oder so

        // ----------------------------
        // Abhören
        // ----------------------------
        // Lokalen Endpunkt definieren (wo Nachrichten empfangen werden).
        // Einen neuen Thread für den Empfang eingehender Nachrichten erstellen.
        Debug.Log("start thread");
        receiveThread = new Thread(
            new ThreadStart(ReceiveData));
        receiveThread.IsBackground = true;
        receiveThread.Start();
    }

    // receive thread
    private void ReceiveData()
    {
        Debug.Log("thread started");
        client = new UdpClient(port);
        while (threatRunning)
        {
            try
            {
                if (client == null) {
                    client = new UdpClient(port);
                    Debug.Log("Create new Client");
                }
                // Bytes empfangen.
                IPEndPoint anyIP = new IPEndPoint(IPAddress.Any, 0);
                byte[] data = client.Receive(ref anyIP);
                // Bytes mit der UTF8-Kodierung in das Textformat kodieren.
                string udpText = Encoding.UTF8.GetString(data);

                Debug.Log("recive: " + udpText);

                UdpDataRec newUdpRec = getJasonDatafromTxt(udpText);
                newUdpRec.ip = anyIP.Address.ToString();
                
                setUdpData(newUdpRec);
                //Thread.Sleep(1);

            }
            catch (Exception err)
            {
                print(err.ToString());
            }
        }
    }

    void setUdpData(UdpDataRec data)
    {
        //empty state
        if (string.IsNullOrEmpty(data.state))
            return;
        switch (data.state)
        {
            case "name":
                PlayerData.addPlayer("tippt...", data.ip, data.id, data.state);
                bUserRegister = true;
                bUpdateUser = true;
                Udp_send.sendMessage(data.ip, "name");
                break;
            case "restart":
                PlayerData.removePlayer(data.id);
                Udp_send.sendMessage(data.ip, data.state);
                bUpdateUser = true;
                break;
            case "register":
                PlayerData.addPlayer(data.value, data.ip, data.id, data.state);
                bUserRegister = true;
                bUpdateUser = true;
                Udp_send.sendMessage(data.ip, data.state);
                break;
            case "ready":
                bPlayerReady = true;
                PlayerData.setState(data.id, data.state);
                bUpdateUser = true;
                bUserRegister = true;
                Udp_send.sendMessage(data.ip, data.state);
                break;
            case "not ready":
                PlayerData.setState(data.id, data.state);
                bUpdateUser = true;
                bUserRegister = true;
                Udp_send.sendMessage(data.ip, data.state);
                break;
            default:
                Debug.Log("Wrning: unhandled state: " + data.state);
                break;
        }
    }

    // Update is called once per frame
    void FixedUpdate() {
        //Button-Sounds
        if(bUserRegister){
            _audioManager.MenuPlayerRegistered();
            bUserRegister = false;
        }
        if(bMenuAcknowledge){
            _audioManager.MenuAcknowledge();
            bMenuAcknowledge = false;
        }
        if (bPlayerReady) {
            _audioManager.MenuAcknowledge();
            bPlayerReady = false;
        }
        //update user text
        if (bUpdateUser) {
            _gameManager.updateUserText();
            bUpdateUser = false;
        }


    }

    public UdpDataRec getJasonDatafromTxt(String text)
    {
        UdpDataRec playerData = new UdpDataRec();
        playerData = JsonUtility.FromJson<UdpDataRec>(text);
        return playerData;
    }

    public void OnDestroy()
    {
        threatRunning = false;
        if (client != null)
            client.Close();
        if (receiveThread.IsAlive)
            receiveThread.Abort();
    }

    public void OnApplicationQuit()
    {
        threatRunning = false;
        if (client != null)
            client.Close();
        if (receiveThread.IsAlive)
            receiveThread.Abort();
    }

}


/*
    -----------------------
    UDP-Receive (send to)
    -----------------------
    // [url]http://msdn.microsoft.com/de-de/library/bb979228.aspx#ID0E3BAC[/url]
   
   
    // > receive
    // 127.0.0.1 : 8051
   
    // send
    // nc -u 127.0.0.1 8051
 
*/
