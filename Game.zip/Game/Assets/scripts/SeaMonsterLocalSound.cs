﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SeaMonsterLocalSound : MonoBehaviour
{

    public AudioSource[] sources;
    private enum Soundids
    {
        grumble,
        quake,
        move
    };

    // Start is called before the first frame update
    void Start()
    {
        sources = GetComponents<AudioSource>();
    }

    public void PlayGrumble()
    {
        if (sources[(int)Soundids.grumble] == null)
        {
            return;
        }

        // don't play if sound still audible or quake sound playing
        if ((sources[(int)Soundids.grumble].isPlaying
            && sources[(int)Soundids.grumble].time <= 2.1f)
            || sources[(int)Soundids.move].isPlaying)
        {
            return;
        }

        sources[(int)Soundids.grumble].Play();
    }

    public void PlayQuake()
    {
        if (sources[(int)Soundids.quake] == null)
        {
            return;
        }

        sources[(int)Soundids.quake].Play();
    }

    public void PlayMoveWater()
    {
        if (sources[(int)Soundids.move] == null)
        {
            return;
        }

        sources[(int)Soundids.move].Play();
    }
}
