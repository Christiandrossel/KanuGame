﻿/*
    -----------------------
    UDP-Send
    -----------------------
    // [url]http://msdn.microsoft.com/de-de/library/bb979228.aspx#ID0E3BAC[/url]
   
    // > gesendetes unter
    // 127.0.0.1 : 8050 empfangen
   
    // nc -lu 127.0.0.1 8050
 
        // todo: shutdown thread at the end
*/

using UnityEngine;
using System.Collections;
using System;
using System.Text;
using System.Net;
using System.Net.Sockets;

public static class Udp_send
{
    public static int _port = 8052;

    // "connection" things
    static UdpClient _client = new UdpClient();
    
    public static void sendMessage(string ip, string message) {
        UdpSendData sendData = new UdpSendData(message);
        IPEndPoint remoteEndPoint = new IPEndPoint(IPAddress.Parse(ip), _port);
        // Daten mit der UTF8-Kodierung in das Binärformat kodieren.

        string text = JsonUtility.ToJson(sendData);

        Debug.Log("send: " + text);

        byte[] data = Encoding.UTF8.GetBytes(text);

        // Den Text zum Remote-Client senden.
        int temp = _client.Send(data, data.Length, remoteEndPoint);
    }
    public static void sendMessageToAll(string message){
        for(int i = 0; i < PlayerData.getCount(); i++)
        {
            sendMessage(PlayerData.getIpByIndex(i), message);
        }
    }
    public static void changePort(int p_port)
    {
        _port = p_port;
    }
}

public class UdpSendData
{
    public string state;

    public UdpSendData(string state)
    {
        this.state = state;
    }
    public UdpSendData(string state, bool isLeader) {
        this.state = state;
    }
}
