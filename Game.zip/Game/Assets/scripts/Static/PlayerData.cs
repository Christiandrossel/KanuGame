﻿

using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

#if UNITY_EDITOR
using UnityEngine.SceneManagement;
using UnityEditor.SceneManagement;

using UnityEditor;
[InitializeOnLoad]
public class AutosaveOnRun: ScriptableObject
{
    static AutosaveOnRun()
    {
        EditorApplication.playModeStateChanged += changeScene;
    }
    public static void changeScene(PlayModeStateChange state)
	{
		if(EditorApplication.isPlayingOrWillChangePlaymode && !EditorApplication.isPlaying)
		{
            //speichert alle offenen Scenen bei Spielstart
            EditorSceneManager.SaveOpenScenes();
            //fragt nach speichern alle offenen Scenen bei Spielstart
            //EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo();
        }
	}
}
#endif

public static class PlayerData
{
    //defines
    static int PLAYER_NAME = 0;
    static int PLAYER_IP = 1;
    static int PLAYER_ID = 2;
    static int PLAYER_STATE = 3;

    //List: name|ip|id|state
    private static List<List<string>> _playerData = new List<List<string>>();
    private static int _score = 0;
    private static float _distance = 0;
    private static int _finalscore = 0;
    private static bool _winGame = false;

    //methods
    public static int addPlayer(string name, string ip, string id, string state)
    {
        if (_playerData == null)
            _playerData = new List<List<string>>();
        if (_playerData.Count >= 4)
            return -1;
        foreach (List<string> player in _playerData) {
            if (player.Contains(ip)){
                player[PLAYER_NAME] = name.ToUpper();
                player[PLAYER_IP] = ip;
                player[PLAYER_ID] = id;
                player[PLAYER_STATE] = state;
                return 0;
            }
        }
        List<string> newList = new List<string>();
        newList.Add(name.ToUpper());
        newList.Add(ip);
        newList.Add(id);
        newList.Add(state);

        _playerData.Add(newList);
        return 1;
    }

    public static bool setState(string uuid, string state){

        foreach (List<string> player in _playerData)
        {
            if (player[PLAYER_ID] == uuid) {
                player[PLAYER_STATE] = state;
                return true;
            }
        }
        return false;
    }
    public static int getCount() {
        return _playerData.Count;
    }
    public static string getAllNameString()
    {
        string names = "";
        foreach (List<string> player in _playerData){
            if (names == "")
                names = player[PLAYER_NAME].ToUpper();
            else
                names = names + " + " + player[PLAYER_NAME];
        }
        return names;
    }
    public static void resetData(){
        _score = 0;
        _distance = 0;
        _finalscore = 0;
        _winGame = false;
        foreach (List<string> player in _playerData)
        {
            player.Clear();
        }
        _playerData.Clear();
    }
    public static int getScore(){
        return _score;
    }
    public static int getFinalScore() {
        return _finalscore;
    }
    public static void setFinalScore(int f)
    {
        _finalscore = f;
    }
    public static void setScore(int p)    {
        _score = p;
    }
    public static void addScore(int p){
        _score += p;
    }
    public static float getDistance()
    {
        return _distance;
    }
    public static void setDistance(float d)
    {
        _distance = d;
    }
    public static bool allReady() {
        if (_playerData.Count == 0)
            return false;
        foreach (List<string> player in _playerData)
        {
            if (player[PLAYER_STATE] != "ready")
                return false;
        }
        return true;
    }
    public static List<string> getIpList(){
        List<string> ipList = new List<string>();
        foreach (List<string> player in _playerData){
            ipList.Add(player[PLAYER_IP]);
        }
        return ipList;
    }
    public static string getNameByIndex(int index){
        if (index >= _playerData.Count)
            return "";
        return _playerData[index][PLAYER_NAME];
    }
    public static string getIpByIndex(int index){
        if (index >= _playerData.Count)
            return "";
        return _playerData[index][PLAYER_IP];
    }
    public static string getIdByIndex(int index){
        if (index >= _playerData.Count)
            return "";
        return _playerData[index][PLAYER_ID];
    }
    public static string getStateByIndex(int index){
        if (index >= _playerData.Count)
            return "";
        return _playerData[index][PLAYER_STATE];
    }
    public static bool isLeader(string id){
        if (_playerData[0][PLAYER_ID] == id)
            return true;
        return false;
    }
    public static int existsId(string id)
    {
        for (int i = 0; i < _playerData.Count; i++)
        {
            if (_playerData[i][PLAYER_ID] == id)
                return i;
        }
        return -1;
    }
    public static int existsIp(string ip) {
        for (int i = 0; i < _playerData.Count; i++) {
            if (_playerData[i][PLAYER_IP] == ip)
                return i;
        }
        return -1;
    }
    public static void setWinGame(bool value)
    {
        _winGame = value;
    }
    public static bool getWinGame()
    {
        return _winGame;
    }
    public static bool removePlayer(string id)
    {
        int index = existsId(id);
        if (index == -1)
            return false;
        _playerData[index].Clear();
        _playerData.Remove(_playerData[index]);
        return true;
    }
    //public static bool checkChangeIdByIp(string p_id, string p_ip) {
    //    //return true -> changed id
    //    int index = existsIp(p_ip);
    //    if (index == -1)
    //        return false;
    //    if(_playerData[index][PLAYER_ID] == p_id)
    //        return false;
    //    _playerData[index][PLAYER_ID] = p_id;
    //    return true;
    //}
    //public static bool checkChangeIpById(string p_ip, string p_id) {
    //    //return true -> changed ip
    //    int index = existsId(p_id);
    //    if (index == -1)
    //        return false;
    //    if (_playerData[index][PLAYER_IP] == p_ip)
    //        return false;
    //    _playerData[index][PLAYER_IP] = p_ip;
    //    return true;
    //}

}
