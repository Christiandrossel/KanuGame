﻿using System.Collections;
using UnityEngine;
using UnityEngine.Audio;

namespace Audio
{
    [System.Serializable]
    public class Sound
    {
        private AudioSource _audioSource;
        public string clipName;
        public AudioClip clip;
        [Tooltip("Sets whether the sound should play through an Audio Mixer first or directly to the Audio Listener")]
        public AudioMixerGroup Output;
        public bool bypassReverb;
        public bool playOnAwake;
        public bool loop;
        [Tooltip("Sets whether the sound should be paused when audio system gets paused.")]
        public bool ignorePause;
        [Range(0.0f, 1.0f)]
        public float volume;
        [Tooltip("Sets the frequency of the sound. Use this to slow down or speed up the sound.")]
        [Range(-3.0f, 3.0f)]
        public float pitch;
        [Tooltip("Sets the position in the stereo field of 2D sounds.")]
        [Range(-1.0f, 1.0f)]
        public float stereoPan;
        [Tooltip("Sets how much this AudioSource is treated as 3D source. 0.0 makes the sound full 2D, 1.0 makes it full 3D.")]
        [Range(0.0f, 1.0f)]
        public float spatialBlend;
        [Tooltip("[0, 1] is a linear range while [1, 1.1] lets you boost the reverb mix by 10dB.")]
        [Range(0.0f, 1.1f)]
        public float reverbZoneMix;
        [Range(0.0f, 5.0f)]
        public float dopplerLevel;
        [Range(0, 360)]
        public int spread;
        [Min(0.0f)]
        public float minDistance;
        [Min(1.01f)]
        public float maxDistance;

        public float InitialVolume { get; private set; }

        public void SetParentTransform(Transform transform)
        {
                _audioSource.transform.parent = transform;
        }

        public bool IsPlaying
        {
            get
            {
                return _audioSource.isPlaying;
            }
        }

        public GameObject GameObject
        {
            get
            {
                return _audioSource.gameObject;
            }
        }

        public bool SetAudioSource(AudioSource audioSource)
        {
            if (audioSource == null)
                return false;
            _audioSource = audioSource;
            _audioSource.clip = clip;
            _audioSource.outputAudioMixerGroup = Output;
            _audioSource.bypassReverbZones = bypassReverb;
            _audioSource.clip.name = clipName;
            _audioSource.loop = loop;
            _audioSource.volume = volume;
            InitialVolume = volume;
            _audioSource.pitch = pitch;
            _audioSource.panStereo = stereoPan;
            _audioSource.spatialBlend = spatialBlend;
            _audioSource.reverbZoneMix = reverbZoneMix;
            _audioSource.dopplerLevel = dopplerLevel;
            _audioSource.spread = spread;
            _audioSource.minDistance = minDistance;
            _audioSource.maxDistance = maxDistance;
            _audioSource.ignoreListenerPause = ignorePause;

            if (playOnAwake)
            {
                _audioSource.Play();
            }
            return true;
        }

        public void SetPitch(float p)
        {
            _audioSource.pitch = p;
        }

        public void SetVolume(float v)
        {
            _audioSource.volume = v;
        }

        public void Play()
        {
            _audioSource.Play();
        }

        public void PlayOneShot()
        {
            _audioSource.PlayOneShot(_audioSource.clip);
        }

        public void Stop()
        {
            _audioSource.Stop();
        }

        public void Pause()
        {
            _audioSource.Pause();
        }

        public void UnPause()
        {
            _audioSource.UnPause();
        }

        public IEnumerator FadeOut(float fadeTime)
        {
            float startVolume = _audioSource.volume;

            while (_audioSource.volume > 0)
            {
                _audioSource.volume -= startVolume * (Time.deltaTime / fadeTime);

                yield return null;
            }

            _audioSource.Stop();
            Debug.Log("Reached end of FadeOut");
            SetVolume(startVolume);
        }

        public IEnumerator FadeIn(float fadeTime)
        {
            float startVolume = 0.1f;
            _audioSource.volume = 0f;

            while (_audioSource.volume < InitialVolume)
            {
                _audioSource.volume += startVolume * (Time.deltaTime / fadeTime);

                yield return null;
            }
        }
    }
}