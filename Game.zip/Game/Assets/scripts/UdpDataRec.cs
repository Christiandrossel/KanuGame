﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UdpDataRec
{
    
    public float speed= 0;
    public int side = 0;
    public string id;
    public string ip;
    public string state;
    public string value;
    public bool newHit = false;


    public void setData(UdpDataRec newData){
        speed = newData.speed;
        side = newData.side;
        id = newData.id;
        ip = newData.ip;
        state = newData.state;
        value = newData.value;
    }
    public void resetData(){
        speed = 0.0f;
        side = 0;
        id = "";
        ip = "";
        state = "";
        value = "";
    }
}
