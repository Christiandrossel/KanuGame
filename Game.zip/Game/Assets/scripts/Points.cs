﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using Audio;


public class Points : MonoBehaviour
{
    public Text point = null;
    public Text distance = null;
    public Text result = null;
    public float waitTimeBefor = 2;
    public int pointsPerFrame = 3;
    public AudioManager _audioManager;

    private float timer = 0;
    private float timerMax = 0;
    private int addPoint = 0;
    private int subPoint = 0;
    private int subDistance = 0;

    private bool Waited(float seconds)
    {
        timerMax = seconds;
        timer += Time.deltaTime;
        if (timer >=timerMax)
        {
            return true;
        }
        return false;

    }

    // Start is called before the first frame update
    void Start()
    {
        point.text = PlayerData.getScore().ToString();
        distance.text = PlayerData.getDistance().ToString("0");
        PlayerData.setFinalScore(PlayerData.getScore() + (int)PlayerData.getDistance());
        //result.text = (PlayerData.getScore() + (int)PlayerData.getDistance()).ToString();
        _audioManager = FindObjectOfType<AudioManager>();

        subPoint = PlayerData.getScore();
        subDistance = (int)PlayerData.getDistance();
    }

    // Update is called once per frame
    void Update()
    {
        //if (!Waited(5)) return; // Wartezeit: 5 Sekunden
        //SceneManager.LoadScene("ScoreTable");

        result.text = addPoint.ToString();

        if (!Waited(waitTimeBefor)) return;
        
        if (subPoint > 0)
        {
            subPoint -= pointsPerFrame;
            point.text = subPoint.ToString();
        }
        else
        {
            subPoint = 0;
            point.text = subPoint.ToString();

            if (subDistance > pointsPerFrame)
            {
                subDistance -= pointsPerFrame;
                distance.text = subDistance.ToString();
            }
            else
            {
                subDistance = 0;
                distance.text = subDistance.ToString();
            }
        }
       

        

        if ((PlayerData.getScore() + (int)PlayerData.getDistance()) <= addPoint)
        {
            result.text = (PlayerData.getScore() + (int)PlayerData.getDistance()).ToString();
            PlayerData.setFinalScore(addPoint);
            //if (!Waited(2)) return; // Wartezeit: 5 Sekunden
            //SceneManager.LoadScene("ScoreTable");
            _audioManager.StopPointsTally();
            Invoke("nextScene", waitTimeBefor);
        }
        else
        {
            addPoint+=pointsPerFrame;
            _audioManager.StartPointsTally();
        }
    }


    public void nextScene()
    {
        SceneManager.LoadScene("ScoreTable");
    }
}
