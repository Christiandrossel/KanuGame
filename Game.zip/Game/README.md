# Unity project kanu_fahren

Project uses Unity version 2018.3.11f1  
Please do not update to a newer version!

Tastatur-Steuerung des Spiels in Kayak-Level:
	esc: 		beenden des Spiels
	space:		resetet das Spiel (z.B. beim feststecken)
	
	W:			aktiviert das Monster
	S:			deaktiviertz das Monster
	
	T:			pausiert das Spiel
	Shift+T:	führt das Spiel weiter
	
	O:			gameOver
	I:			macht eine Aufnahme und sppeichet sie im Spiel-Ordner unter Aufnahmen
	
	G:			schaltet GUI aus
	Shift+G:	schaltet GUI ein


Tastatur-Steuerung des Spiels in Manü:
	esc: 		beenden des Spiels


