package de.htwdd.rudersteuerung.sensors;

import de.htwdd.rudersteuerung.connector.IUnityConnector;
import de.htwdd.rudersteuerung.connector.model.PaddleSide;

public class OrientationAnalyzer extends MotionAnalyzer {

    private Double ox = null, oy = null, oz = null;

    public OrientationAnalyzer(IUnityConnector unityConnector) {
        super(unityConnector);
    }

    @Override
    public void onSensorUpdate(float[] acceleration, float[] orientation) {
        if (System.currentTimeMillis() - lastTimestamp > 100) {

            // Convert orientation values to degrees
            double x = radiansToDegrees(orientation[1]);
            double y = radiansToDegrees(orientation[0]);
            double z = radiansToDegrees(orientation[2]);

            double dz = getDZ(oz, z);

            if ((y < 90) && (y > 30)) {
                PaddleSide side = PaddleSide.LEFT;
                float speed = (float) -dz;
                sendStroke(side, speed);
            } else if ((y > -90) && (y < -30)) {
                PaddleSide side = PaddleSide.RIGHT;
                float speed = (float) dz;
                sendStroke(side, speed);
            }

            // Store current timestamp
            lastTimestamp = System.currentTimeMillis();

            // Override old state
            ox = x;
            oy = y;
            oz = z;
        }
    }

    private double getDZ(Double old_z, Double new_z) {

        // No old value found
        if (old_z == null) {
            return 0;
        }

        // Calculate delta Z
        double dz = new_z - old_z;

        // Check for rotation overflows
        // TODO: Replace Hotfix for rotation clipping with multiple value analysis
        while (dz < -90) {
            dz += 180;
        }
        while (dz > 90) {
            dz -= 180;
        }

        // Return result
        return dz;
    }

}
