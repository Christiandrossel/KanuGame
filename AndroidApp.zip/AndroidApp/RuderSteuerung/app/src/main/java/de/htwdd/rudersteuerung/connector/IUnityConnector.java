package de.htwdd.rudersteuerung.connector;

import android.support.annotation.Nullable;

import de.htwdd.rudersteuerung.connector.model.GameState;
import de.htwdd.rudersteuerung.connector.model.PaddleSide;

public interface IUnityConnector {
    boolean readyToSend();

    // Send Steering values while in-game
    void send(PaddleSide side, float speed);

    // Send State-Changing events
    void send(GameState state, @Nullable String name);

    void addListener(IUnityMessageListener listener);
}
