package de.htwdd.rudersteuerung.sensors;

import java.util.ArrayList;
import java.util.List;

import de.htwdd.rudersteuerung.connector.IUnityConnector;
import de.htwdd.rudersteuerung.connector.model.PaddleSide;

public class AccelerationAnalyzer extends MotionAnalyzer {

    private List<Float> _accelerationList;
    private float _oldSpeed = 0;

    public AccelerationAnalyzer(IUnityConnector unityConnector) {
        super(unityConnector);
    }

    @Override
    public void onSensorUpdate(float[] acceleration, float[] orientation) {
        if (_accelerationList == null)
            _accelerationList = new ArrayList<>();
        float calcAcceleration = _calcAcceleration(acceleration[0], acceleration[2], orientation[1]);
        _accelerationList.add(calcAcceleration);

        if (System.currentTimeMillis() - lastTimestamp > 100) {
            // Convert orientation values to degrees
            double y = radiansToDegrees(orientation[0]);

            // Calculate speed
            float z = average(_accelerationList);
            float speed = -z * 5 + 0.85f * _oldSpeed;

            if (0.6 > z && z > -0.6)
                speed = 0 + 0.6f * _oldSpeed;
            _accelerationList.clear();
            _oldSpeed = speed;

            if ((y < 90) && (y > 30)) {
                PaddleSide side = PaddleSide.LEFT;
                sendStroke(side, speed);
            } else if ((y > -90) && (y < -30)) {
                PaddleSide side = PaddleSide.RIGHT;
                sendStroke(side, speed);
            }

            // Store current timestamp
            lastTimestamp = System.currentTimeMillis();
        }
    }

    /**
     * Returns the combined acceleration by combining the X and Z acceleration
     */
    private float _calcAcceleration(float accelerationX, float accelerationZ, float radY) {
        float acceleration;
        double ratio = Math.sin(radY);
        acceleration = (float) (accelerationX * (1 - Math.abs(ratio)) + accelerationZ * ratio);
        return acceleration;
    }

}
