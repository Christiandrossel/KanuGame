package de.htwdd.rudersteuerung.connector;

import android.os.NetworkOnMainThreadException;
import android.support.annotation.Nullable;
import android.util.Log;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonParseException;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;
import java.util.UUID;

import de.htwdd.rudersteuerung.connector.model.GameState;
import de.htwdd.rudersteuerung.connector.model.PaddleSide;
import de.htwdd.rudersteuerung.connector.model.ReceivingDto;
import de.htwdd.rudersteuerung.connector.model.SendingDto;

public class UnityConnector implements IUnityConnector {
    private static int UNITY_PORT = 8051;
    private static int APP_PORT = 8052;
    private static int MSG_BUFFER = 1000;

    private DatagramSocket _socket = null;
    private DatagramSocket _receivingSocket = null;
    private DatagramPacket _packet = null;

    private List<IUnityMessageListener> _listeners = new ArrayList<>();
    private Thread _receivingThread;

    private String _privateId = null;

    public UnityConnector() {
        String uuid = UUID.randomUUID().toString();
        _privateId = new StringTokenizer(uuid, "-").nextToken();
    }

    public UnityConnector(String ip) {
        this();
        setIp(ip);
    }

    public boolean setIp(String ipAddress) {
        try {
            byte[] message = new byte[MSG_BUFFER];
            InetAddress ipAddr = InetAddress.getByName(ipAddress);
            _socket = new DatagramSocket();
            _packet = new DatagramPacket(message, MSG_BUFFER, ipAddr, UNITY_PORT);
        } catch (SocketException ex) {
            Log.e("UnityConnector", "Could not set Port", ex);
            _handleError();
            return false;
        } catch (UnknownHostException ex) {
            Log.e("UnityConnector", "Could not find Host " + ipAddress, ex);
            _handleError();
            return false;
        } catch (NetworkOnMainThreadException ex) {
            Log.e("UnityConnector", "Could external Host not allowed " + ipAddress, ex);
            _handleError();
            return false;
        }
        _createThread();
        return true;
    }

    public boolean readyToSend() {
        if (_socket != null || _packet != null)
            return true;
        else
            return false;
    }

    public void send(final PaddleSide side, final float speed) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                SendingDto dto = new SendingDto(side.val(), speed, _privateId);
                String json = new Gson().toJson(dto);
                byte[] msg = json.getBytes();

                _packet.setData(msg);
                try {
                    _socket.send(_packet);
                } catch (IOException ex) {
                    Log.e("UnityConnector", "Something weird happened:", ex);
                    _handleError();
                }
            }
        }).start();
    }

    public void send(final GameState state, @Nullable final String name) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                SendingDto dto = new SendingDto(state, name, _privateId);
                String json = new Gson().toJson(dto);
                byte[] msg = json.getBytes();

                _packet.setData(msg);
                try {
                    _socket.send(_packet);
                } catch (IOException ex) {
                    Log.e("UnityConnector", "Something weird happened:", ex);
                    _handleError();
                }
            }
        }).start();
    }

    @Override
    public void addListener(IUnityMessageListener listener) {
        if (!_listeners.contains(listener))
            _listeners.add(listener);
    }

    //////////////////////////////////////////
    // private Methods

    private void _handleError() {
        if (_socket != null)
            _socket.close();
        _socket = null;
        _packet = null;
    }

    private void _createThread() {
        try {
            if (_receivingSocket == null)
                _receivingSocket = new DatagramSocket(APP_PORT);

            _receivingThread = new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        byte[] buffer = new byte[MSG_BUFFER];
                        DatagramPacket packet = new DatagramPacket(buffer, MSG_BUFFER);
                        Gson gson = new GsonBuilder().setLenient().create();

                        while (true) {
                            _receivingSocket.receive(packet);
                            String msg = new String(packet.getData(), 0, packet.getLength());
                            try {
                                ReceivingDto message = gson.fromJson(msg, ReceivingDto.class);

                                Log.d("ReceivingThread", "Message received! " + message.getGameState());
                                for (IUnityMessageListener listener : _listeners) {
                                    listener.messageReceived(message);
                                }
                            } catch (JsonParseException jsonEx) {
                                Log.e("ReceivingThread", "Error Parsing " + msg, jsonEx);
                            }
                        }
                    } catch (Exception e) {
                        Log.e("receivingThread", "Error", e);
                    }
                }
            });
            _receivingThread.start();
        } catch (SocketException e) {
            e.printStackTrace();
            _receivingSocket.close();
        }
    }
}
