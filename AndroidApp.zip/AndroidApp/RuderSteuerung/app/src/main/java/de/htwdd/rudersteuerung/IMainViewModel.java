package de.htwdd.rudersteuerung;

public interface IMainViewModel {

    /**
     * set the IP Address for Unity
     *
     * @param ip the ip Address, where the Unity System runs
     * @return returns True, if the given IP is possible
     */
    boolean setIp(String ip);

    /**
     * Set the Name for this Device in Unity
     *
     * @param name the Name to set for Unity for this device
     */
    void setName(String name);

    /**
     * Sets the User Ready or not Ready in Unity
     *
     * @param isReady true -> User is Ready
     *                false-> User is not Ready
     */
    void setReady(boolean isReady);

    /**
     * Sends a request to Unity to pause the game
     */
    void pauseGameplay();

    /**
     * Sends a request to Unity to resume the game
     */
    void resumeGameplay();

    /**
     * Sends a request to Unity to stop the game
     */
    void stopGameplay();

    /**
     * Sends a request to Unity to restart the game
     *
     * @param saveName true -> Username is Saved and stays registered
     *                 false-> Username is deleted and User can enter Name again
     */
    void restartGame(boolean saveName);

    /**
     * Changes to Name Fragment
     */
    void enterGame();

    /**
     * Sends request to Unity to roll the credits
     */
    void startCredits();

    void goBack();
}
