package de.htwdd.rudersteuerung;

import de.htwdd.rudersteuerung.connector.model.GameState;

public interface IStateChangedCallback {
    void onStateChanged(GameState newState);
}
