package de.htwdd.rudersteuerung.sensors;

public interface SensorListener {
    /**
     * Is called by SensorService after the class which implemented this interface is registered as listener.
     * Gets called on every sensor update for either acceleration or orientation
     */
    void onSensorUpdate(float[] acceleration, float[] orientation);
}
