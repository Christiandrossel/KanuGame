package de.htwdd.rudersteuerung.ui;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import de.htwdd.rudersteuerung.IMainViewModel;
import de.htwdd.rudersteuerung.R;

public class NameFragment extends Fragment {

    private IMainViewModel _viewModel = null;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_name, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        _setupGui(view);

        super.onViewCreated(view, savedInstanceState);
    }

    //////////////////////////////////////////
    // Private Methods

    private void _setupGui(final View view) {
        if (getActivity() instanceof IMainViewModel)
            _viewModel = (IMainViewModel) getActivity();
        else
            return;

        final Button okBtn = view.findViewById(R.id.btn_name_ok);
        okBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText etName = view.findViewById(R.id.et_player_name);
                String name = etName.getText().toString();
                if (!name.equals("")) {
                    _viewModel.setName(name);
                } else {
                    Toast.makeText(getContext(), "Es muss ein Name eingegeben werden!", Toast.LENGTH_SHORT).show();
                }
            }
        });

        final Button backBtn = view.findViewById(R.id.btn_name_back);
        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                _viewModel.goBack();
            }
        });
    }
}
