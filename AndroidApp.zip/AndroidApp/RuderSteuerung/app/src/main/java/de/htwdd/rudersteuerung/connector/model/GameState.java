package de.htwdd.rudersteuerung.connector.model;

import com.google.gson.annotations.SerializedName;

public enum GameState {
    @SerializedName("name")
    NAME,

    @SerializedName("register")
    REGISTER,

    @SerializedName("not ready")
    NOTREADY,

    @SerializedName("ready")
    READY,

    @SerializedName("running")
    RUNNING,

    @SerializedName("pause")
    PAUSE,

    @SerializedName("restart")
    RESTART;
}
