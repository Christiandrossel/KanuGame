package de.htwdd.rudersteuerung.ui;

import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.VideoView;

import de.htwdd.rudersteuerung.IMainViewModel;
import de.htwdd.rudersteuerung.R;

public class VideoplayerCreditsFragment extends Fragment {

    private IMainViewModel _viewModel = null;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_videoplayer_credits, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        _setupGui(view);

        super.onViewCreated(view, savedInstanceState);
    }

    //////////////////////////////////////////
    // Private Methods

    private void _setupGui(final View view) {
        if (getActivity() instanceof IMainViewModel)
            _viewModel = (IMainViewModel) getActivity();
        else
            return;

        VideoView video = view.findViewById(R.id.videoView);
        Uri videoPath = Uri.parse("android.resource://" + getActivity().getPackageName() + "/" + R.raw.credits);
        video.setVideoURI(videoPath);
        video.start();
        video.requestFocus();

        final Button menuBtn = view.findViewById(R.id.btn_show_menu);
        final Button creditsBtn = view.findViewById(R.id.btn_credits_back);

        menuBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int visibility = creditsBtn.getVisibility();
                if (visibility == View.VISIBLE) {
                    creditsBtn.setVisibility(View.INVISIBLE);
                } else {
                    creditsBtn.setVisibility(View.VISIBLE);
                }
            }
        });

        creditsBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                _viewModel.restartGame(false);
            }
        });

        video.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            public void onCompletion(MediaPlayer mp) {
                _viewModel.restartGame(false);
            }
        });
    }
}
