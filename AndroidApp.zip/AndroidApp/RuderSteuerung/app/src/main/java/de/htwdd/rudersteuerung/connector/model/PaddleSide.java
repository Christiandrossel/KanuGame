package de.htwdd.rudersteuerung.connector.model;

public enum PaddleSide {
    LEFT(-1),
    NONE(0),
    RIGHT(1);

    private final int _value;

    PaddleSide(int value) {
        _value = value;
    }

    public int val() {
        return _value;
    }
}
