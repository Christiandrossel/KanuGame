package de.htwdd.rudersteuerung.connector.model;

import com.google.gson.annotations.SerializedName;

public class ReceivingDto {

    @SerializedName("state")
    private GameState _state;

    public GameState getGameState() {
        return _state;
    }
}
