package de.htwdd.rudersteuerung;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;

import de.htwdd.rudersteuerung.connector.IUnityMessageListener;
import de.htwdd.rudersteuerung.connector.UnityConnector;
import de.htwdd.rudersteuerung.connector.model.GameState;
import de.htwdd.rudersteuerung.connector.model.ReceivingDto;
import de.htwdd.rudersteuerung.sensors.AccelerationAnalyzer;
import de.htwdd.rudersteuerung.sensors.AnalyzerType;
import de.htwdd.rudersteuerung.sensors.MotionAnalyzer;
import de.htwdd.rudersteuerung.sensors.OrientationAnalyzer;
import de.htwdd.rudersteuerung.sensors.SensorService;
import de.htwdd.rudersteuerung.ui.GameFragment;
import de.htwdd.rudersteuerung.ui.IpFragment;
import de.htwdd.rudersteuerung.ui.MainFragment;
import de.htwdd.rudersteuerung.ui.NameFragment;
import de.htwdd.rudersteuerung.ui.RetryFragment;
import de.htwdd.rudersteuerung.ui.VideoplayerCreditsFragment;
import de.htwdd.rudersteuerung.ui.WaitFragment;

public class MainActivity extends AppCompatActivity implements IMainViewModel, IUnityMessageListener {

    private static String START_FRAGMENT = "Main";
    private SensorService _sensorService = null;
    private UnityConnector _connector = null;
    private String _currentName;
    private GameState _currentState;
    private IStateChangedCallback _callback;

    //////////////////////////////////////////
    // Activity implementation
    //////////////////////////////////////////

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fullscreen);

        // Create unity connector
        _connector = new UnityConnector();
        _connector.addListener(this);

        // Create motion analyzer
        MotionAnalyzer analyzer;
        AnalyzerType type = AnalyzerType.Acceleration;
        switch (type) {
            case Orientation:
                analyzer = new OrientationAnalyzer(_connector);
                break;
            case Acceleration:
                analyzer = new AccelerationAnalyzer(_connector);
                break;
            default:
                throw new RuntimeException("Unknown analyzer type");
        }

        // Sensors initialization
        _sensorService = new SensorService(this);
        _sensorService.registerListener(analyzer);

        // Create Fragment
        FragmentManager manager = getSupportFragmentManager();
        manager.beginTransaction()
                .replace(R.id.fragment_container, new IpFragment())
                .commit();

        _currentState = GameState.RESTART;
    }

    @Override
    public void onBackPressed() {

    }

    @Override
    protected void onDestroy() {
        _sensorService.stopSensors();
        super.onDestroy();
    }

    //////////////////////////////////////////
    // IMainViewModel implementation
    //////////////////////////////////////////

    @Override
    public boolean setIp(String ip) {
        boolean result = _connector.setIp(ip);

        if (result) {
            FragmentManager manager = getSupportFragmentManager();
            manager.beginTransaction()
                    .replace(R.id.fragment_container, new MainFragment())
                    .commit();
        }
        return result;
    }

    @Override
    public void enterGame() {
        _connector.send(GameState.NAME, null);
    }

    @Override
    public void setName(String name) {
        _currentName = name;
        _connector.send(GameState.REGISTER, name);
    }

    @Override
    public void setReady(boolean isReady) {
        if (isReady)
            _connector.send(GameState.READY, null);
        else
            _connector.send(GameState.NOTREADY, null);
    }

    @Override
    public void pauseGameplay() {
        _connector.send(GameState.PAUSE, null);
    }

    @Override
    public void resumeGameplay() {
        _connector.send(GameState.RUNNING, null);
    }

    @Override
    public void stopGameplay() {
        _connector.send(GameState.RESTART, null);
    }

    @Override
    public void restartGame(boolean saveName) {

        if (saveName) {
            _connector.send(GameState.REGISTER, _currentName);
        } else {
            FragmentManager manager = getSupportFragmentManager();
            manager.beginTransaction()
                    .replace(R.id.fragment_container, new MainFragment())
                    .commit();
            _currentName = null;
        }
    }

    @Override
    public void startCredits() {
        FragmentManager manager = getSupportFragmentManager();
        manager.beginTransaction()
                .replace(R.id.fragment_container, new VideoplayerCreditsFragment())
                .commit();
    }

    @Override
    public void goBack() {
        if (_currentState == GameState.NAME) {
            _connector.send(GameState.RESTART, null);
            _currentState = GameState.RESTART;

            FragmentManager manager = getSupportFragmentManager();
            manager.beginTransaction()
                    .replace(R.id.fragment_container, new MainFragment())
                    .commit();
        } else if (_currentState == GameState.REGISTER ||
                _currentState == GameState.NOTREADY ||
                _currentState == GameState.READY)
        {
            _connector.send(GameState.NAME, null);
        }
    }

    //////////////////////////////////////////
    // IUnityMessageListener implementation
    //////////////////////////////////////////

    @Override
    public void messageReceived(ReceivingDto message) {

        if (message.getGameState() == GameState.REGISTER ||
                _currentState != message.getGameState()) {
            Fragment nextFragment = null;
            switch (message.getGameState()) {
                case NAME:
                    nextFragment = new NameFragment();
                    break;
                case REGISTER:
                    nextFragment = new WaitFragment();
                    _callback = (WaitFragment)nextFragment;
                    break;
                case RUNNING:
                    nextFragment = new GameFragment();
                    _callback = (GameFragment)nextFragment;
                    _sensorService.startSensors();
                    break;
                case PAUSE:
                    _sensorService.stopSensors();
                    break;
                case RESTART:
                    nextFragment = new RetryFragment();
                    _sensorService.stopSensors();
                    break;
            }
            _currentState = message.getGameState();

            if (nextFragment != null) {
                FragmentManager manager = getSupportFragmentManager();
                manager.beginTransaction()
                        .replace(R.id.fragment_container, nextFragment)
                        .commit();
            }

            if(_callback != null)
                _callback.onStateChanged(message.getGameState());
        }
    }
}
