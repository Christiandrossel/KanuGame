package de.htwdd.rudersteuerung.connector.model;

import com.google.gson.annotations.SerializedName;

public class SendingDto {

    @SerializedName("side")
    private int _side;

    @SerializedName("speed")
    private float _speed;

    @SerializedName("id")
    private String _id;

    @SerializedName("state")
    private GameState _state;

    @SerializedName("value")
    private String _name;

    public SendingDto(int side, float force, String id) {
        _speed = force;
        _side = side;
        _id = id;
    }

    public SendingDto(GameState state, String name, String id) {
        _speed = 0f;
        _side = 0;
        _state = state;
        _id = id;
        _name = name;
    }

    public int getSide() {
        return _side;
    }

    public void setSide(int side) {
        this._side = side;
    }

    public float getSpeed() {
        return _speed;
    }

    public void setSpeed(float speed) {
        this._speed = speed;
    }
}
