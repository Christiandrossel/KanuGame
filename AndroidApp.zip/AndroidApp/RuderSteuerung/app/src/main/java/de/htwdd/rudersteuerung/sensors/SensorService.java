package de.htwdd.rudersteuerung.sensors;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.support.annotation.NonNull;

import java.util.ArrayList;
import java.util.List;

/**
 * Reads out the Sensor Data of the Accelerometer and Magnetometer, sends updates out to SensorListeners with:
 * - Orientation (Rotation around x, y, z)
 * - Linear Acceleration along x, y, z
 * To Start the sensor call startSensors(), to listen for Updates use registerListener().
 */
public class SensorService implements SensorEventListener {

    private final float[] _accelerometerValues = new float[3];
    private final float[] _magnetometerValues = new float[3];
    private Context _appContext = null;
    private SensorManager _manager = null;
    private Sensor _accelerometer, _orientationMagnetometer, _orientationAccelerometer;
    private List<SensorListener> _listeners = new ArrayList<>();
    private float[] _orientation = new float[3];
    private float[] _acceleration = new float[3];

    public SensorService(@NonNull Context context) {
        _appContext = context;
        _manager = (SensorManager) _appContext.getSystemService(Context.SENSOR_SERVICE);
    }

    /**
     * Adds a new Listener to the rooster of listeners, that get updates if the listener is not already in it.
     *
     * @param newListener The listener to be added
     */
    public void registerListener(SensorListener newListener) {
        for (SensorListener oldListener : _listeners) {
            if (oldListener.equals(newListener))
                return;
        }

        _listeners.add(newListener);
    }

    /**
     * Removes the listener from the rooster of listeners, that get updates if possible.
     *
     * @param listener The listener to be removed.
     */
    public void unregisterListener(SensorListener listener) {
        _listeners.remove(listener);
    }

    /**
     * Starts all sensors and activates Updates
     */
    public void startSensors() {
        // instantiate the Sensors
        _accelerometer = _manager.getDefaultSensor(Sensor.TYPE_LINEAR_ACCELERATION);
        _orientationMagnetometer = _manager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);
        _orientationAccelerometer = _manager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);

        // register this class as listener for every sensor-change (if the device has this sensor)
        if (_accelerometer != null) {
            _manager.registerListener(this, _accelerometer, SensorManager.SENSOR_DELAY_GAME);
        }
        if (_orientationMagnetometer != null) {
            _manager.registerListener(this, _orientationMagnetometer, SensorManager.SENSOR_DELAY_GAME);
        }
        if (_orientationAccelerometer != null) {
            _manager.registerListener(this, _orientationAccelerometer, SensorManager.SENSOR_DELAY_GAME);
        }
    }

    /**
     * Stops all Sensors and deactivates updates, keeps the listeners
     */
    public void stopSensors() {
        _manager.unregisterListener(this);
    }

    //////////////////////////////////////////
    // SensorEventListener implementation

    @Override
    public void onSensorChanged(SensorEvent event) {
        switch (event.sensor.getType()) {
            case Sensor.TYPE_ACCELEROMETER:
            case Sensor.TYPE_MAGNETIC_FIELD:
                _updateOrientation(event);
                break;
            case Sensor.TYPE_LINEAR_ACCELERATION:
                System.arraycopy(event.values, 0, _acceleration, 0, _acceleration.length);
                break;
        }

        _informListeners();
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }

    //////////////////////////////////////////
    // private methods

    private void _updateOrientation(SensorEvent event) {
        if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
            System.arraycopy(event.values, 0, _accelerometerValues, 0, _accelerometerValues.length);
        } else if (event.sensor.getType() == Sensor.TYPE_MAGNETIC_FIELD) {
            System.arraycopy(event.values, 0, _magnetometerValues, 0, _magnetometerValues.length);
        }

        float[] orientationMatrix = new float[9];
        SensorManager.getRotationMatrix(orientationMatrix, null, _accelerometerValues, _magnetometerValues);
        SensorManager.getOrientation(orientationMatrix, _orientation);

        float helper = _orientation[2];
        _orientation[2] = _orientation[0];
        _orientation[0] = _orientation[1];
        _orientation[1] = helper;
    }

    private void _informListeners() {
        for (SensorListener listener : _listeners) {
            listener.onSensorUpdate(_acceleration, _orientation);
        }
    }
}
