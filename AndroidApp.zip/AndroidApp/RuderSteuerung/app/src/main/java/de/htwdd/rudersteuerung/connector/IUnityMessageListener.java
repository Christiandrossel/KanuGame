package de.htwdd.rudersteuerung.connector;

import de.htwdd.rudersteuerung.connector.model.ReceivingDto;

public interface IUnityMessageListener {
    void messageReceived(ReceivingDto message);
}
