package de.htwdd.rudersteuerung.sensors;

import android.util.Log;

import java.util.List;

import de.htwdd.rudersteuerung.connector.IUnityConnector;
import de.htwdd.rudersteuerung.connector.model.PaddleSide;

public abstract class MotionAnalyzer implements SensorListener {

    double lastTimestamp;
    private IUnityConnector connector = null;


    MotionAnalyzer(IUnityConnector unityConnector) {
        connector = unityConnector;
    }

    static float average(List<Float> array) {
        // Check if array is empty
        if (array.isEmpty())
            return 0;
        // Calculate sum of array
        float sum = 0;
        for (Float f : array)
            sum += f;
        // Divide sum by size
        return sum / array.size();
    }

    void sendStroke(PaddleSide side, float speed) {
        if (connector.readyToSend()) {
            connector.send(side, speed);
        }
        Log.d(String.valueOf(side), String.valueOf(speed));
    }

    double radiansToDegrees(float radians) {
        return radians * (180. / Math.PI);
    }

}
