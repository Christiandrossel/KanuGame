package de.htwdd.rudersteuerung.ui;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import de.htwdd.rudersteuerung.IMainViewModel;
import de.htwdd.rudersteuerung.IStateChangedCallback;
import de.htwdd.rudersteuerung.R;
import de.htwdd.rudersteuerung.connector.model.GameState;

public class WaitFragment extends Fragment implements IStateChangedCallback {

    private IMainViewModel _viewModel = null;
    private Boolean isReady = false;

    private Button _readyBtn = null;
    private Button _notReadyBtn = null;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_wait, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        _setupGui(view);

        super.onViewCreated(view, savedInstanceState);
    }

    //////////////////////////////////////////
    // Private Methods

    private void _setupGui(final View view) {
        if (getActivity() instanceof IMainViewModel)
            _viewModel = (IMainViewModel) getActivity();
        else
            return;

        _readyBtn = view.findViewById(R.id.btn_ready);
        _notReadyBtn = view.findViewById(R.id.btn_not_ready);

        _readyBtn.setOnClickListener(_switchReadyStateListener);
        _notReadyBtn.setOnClickListener(_switchReadyStateListener);

        final Button backBtn = view.findViewById(R.id.btn_wait_back);
        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                _viewModel.goBack();
            }
        });
    }

    private View.OnClickListener _switchReadyStateListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            _viewModel.setReady(!isReady);
        }
    };

    @Override
    public void onStateChanged(GameState newState) {
        if(_readyBtn != null && _notReadyBtn != null) {
            if (newState == GameState.NOTREADY) {
                _readyBtn.setBackgroundResource(R.drawable.button);
                _notReadyBtn.setBackgroundResource(R.drawable.selected_button);
                isReady = false;
            }
            if (newState == GameState.READY) {
                _readyBtn.setBackgroundResource(R.drawable.selected_button);
                _notReadyBtn.setBackgroundResource(R.drawable.button);
                isReady= true;
            }
        }
    }
}
