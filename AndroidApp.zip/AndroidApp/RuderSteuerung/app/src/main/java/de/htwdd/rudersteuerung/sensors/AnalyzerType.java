package de.htwdd.rudersteuerung.sensors;

public enum AnalyzerType {
    Acceleration, Orientation
}
