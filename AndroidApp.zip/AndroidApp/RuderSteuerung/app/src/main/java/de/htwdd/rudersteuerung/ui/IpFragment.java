package de.htwdd.rudersteuerung.ui;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import de.htwdd.rudersteuerung.IMainViewModel;
import de.htwdd.rudersteuerung.R;

public class IpFragment extends Fragment {

    private IMainViewModel _viewModel = null;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_ip, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        _setupGui(view);

        super.onViewCreated(view, savedInstanceState);
    }

    //////////////////////////////////////////
    // Private Methods

    private void _setupGui(final View view) {
        if (getActivity() instanceof IMainViewModel)
            _viewModel = (IMainViewModel) getActivity();
        else
            return;

        final Button sendBtn = view.findViewById(R.id.btn_confirm_ip);
        sendBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText etIp = view.findViewById(R.id.et_ip);
                String ipText = etIp.getText().toString();
                if (ipText.equals("") || !_viewModel.setIp(ipText))
                    Toast.makeText(getContext(), "Keine gültige IP Adresse!", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
