package de.htwdd.rudersteuerung.ui;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import de.htwdd.rudersteuerung.IMainViewModel;
import de.htwdd.rudersteuerung.R;

public class RetryFragment extends Fragment {

    private IMainViewModel _viewModel = null;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_retry, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        _setupGui(view);

        super.onViewCreated(view, savedInstanceState);
    }

    //////////////////////////////////////////
    // Private Methods

    private void _setupGui(final View view) {
        if (getActivity() instanceof IMainViewModel)
            _viewModel = (IMainViewModel) getActivity();
        else
            return;

        final Button retryBtn = view.findViewById(R.id.btn_retry);
        retryBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                _viewModel.restartGame(true);
            }
        });

        final Button cancelBtn = view.findViewById(R.id.btn_retry_cancel);
        cancelBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                _viewModel.restartGame(false);
            }
        });
    }
}
