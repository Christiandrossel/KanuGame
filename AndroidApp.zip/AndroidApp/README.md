# Android Kanu Fahren

Dieses Repository ist für die Android Seite des Spiels "Kanu Fahren". 
Über die Android App werden die Sensordaten Aufgenommen und Ausgewertet um Paddelbewegungen vom Benutzer erkennen zu können.

# RuderRecording
App zum Aufzeichnen und abspeichern der Daten des Gyroskops und des Beschleunigungssensors. Aufgenommene Daten werden später 
zum erkennen von Paddelbewegungen benutzt. Sie wird nicht weiter genutzt nach der Entwicklung der richtigen Ruder App.

# RuderSteuerung
Dies ist die App, die zur Steuerung des Unity-Spiels genutzt wird. Die Sensordaten werden erfasst, verarbeitet und als 
Geschwindigkeitsvektoren an Unity weitergegeben. Außerdem kann man das Spiel über die App Starten und Pausieren.

# Datenübertragung
Die Datenübertragung von und zur App erfolgt über einen JSON String, der via UDP übermittelt wird. Der Aufbau der JSON-Strings wird hier näher erläutert.

## App -> Unity

Die Daten werden über den Port 8051 an Unity gesendet.

| Property 	| Datentyp   | Definition |
| -------- 	| ---------- | ---------- |
| side     	| int        | -1-> Paddel links im Wasser  <br> 0 -> Paddel nicht im Wasser  <br>+1 -> Paddel rechts im Wasser |
| speed    	| float      | Kraftvektor, mit dem das Paddel durch das "Wasser" gezogen wird |
| id        | string     | die eindeutige ID des Gerätes |
| state (optional)     | string     | Anforderung von Statusänderungen an das Spiel |
| value (optional)     | string     | Daten für Statusübergänge, beispielsweise beim Registrieren der Name |

Diese Tabelle wird noch weiter Angepasst, ist allerdings für den Dummy 1.1 ausreichend.

##### Beispiel JSON

 `{ "side" : 0, "speed" : 0.523 }` 

## Unity -> App

Die Daten werden am Port 8052 von der App erwartet.

| Property 	| Datentyp   | Definition |
| -------- 	| ---------- | ---------- |
| state    	| string     | Gibt den momentanen Game-State an. Sollte die App versuchen, den Status zu ändern, <br> wird das zuerst von Unity bestätigt. <br> (Bsp.: App sendet Pause -> Unity sendet neuen Zustand -> App wechselt in Pause) |
| isLeader 	| boolean    | Gibt an, ob der Spieler der leader ist |

Diese Tabelle wird noch weiter Angepasst, ist allerdings für den Dummy 1.1 ausreichend.

##### Beispiel JSON

 `{ "state" : "not ready", "isLeader" : true }` 

## Auflistung States

| value 	| Definition |   
| -------- 	| ---------- |
| register  | Gerät registriert sich in Unity, nicht zum versenden von Unity gedacht |
| not ready | Spiel ist im Start-Bildschirm und wartet auf Spieler |        
| ready    	| Spiel ist im Start-Bildschirm und das Spiel kann gestartet werden |
| running   | Spiel wird gerade gespielt  |
| pause     | Spiel wurde pausiert |
| restart | Spiel wird neu gestartet. Alle Teilnehmer müssen sich neu registrieren |

## Zustandsübergänge

![graph](img/graph.png)

| Kante | Sending object                            | Receiving object           | Neuer Zustand |
|-------|-------------------------------------------|----------------------------|---------------|
| 1     | `{ "state": "name" }`                     | `{ "state": "name" }`      | Name          |
| 2     | `{ "state": "restart" }`                  | --                         | Main          |
| 3     | `{ "state": "register", "value": <name>}` | `{ "state": "register" }`  | Unready       |
| 4     | `{ "state": "name" }`                     | `{ "state": "name" }`      | Name          |
| 5     | `{ "state": "ready" }`                    | `{ "state": "ready" }`     | Ready         |
| 6     | `{ "state": "not ready" }`                | `{ "state": "not ready" }` | Unready       |
| 7     | *handled by Unity*                        | `{ "state": "running" }`   | Game          |
| 8     | `{ "state": "pause" }`                    | `{ "state": "pause" }`     | Pause         |
| 9     | `{ "state": "running" }`                  | `{ "state": "running" }`   | Game          |
| 10    | *handled by Unity*                        | `{ "state": "restart" }`   | Retry         |
| 11    | `{ "state": "restart" }`                  | `{ "state": "restart" }`   | Retry         |
| 12    | `{ "state": "register", "value": <name>}` | `{ "state": "register" }`  | Unready       |
| 13    | *handled in backend*                      | --                         | Main          |
