package de.htwdd.ruderrecording;

import android.content.Context;
import android.os.Environment;
import android.util.Log;

import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

public class FileService {
    private final Context _appContext;
    private File _file;

    public FileService(Context appContext)
    {
        _appContext = appContext;
    }

    public void setFile(String fileName)
    {
        if(fileName == null) {
            SimpleDateFormat format = new SimpleDateFormat("dd.MM.yy - hh:mm");
            fileName = format.format(new Date()) + ".txt";
        }
        _file = new File(_appContext.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS), fileName);
    }

    public String getCurrentFile()
    {
        return _file.getName();
    }

    public void writeToFile(String s)
    {
        if(_file == null)
            return;

        try {
            FileOutputStream writer = new FileOutputStream(_file, true);
            writer.write(s.getBytes());
            writer.close();
        } catch (Exception e) {
            Log.e("FileService", "", e);
        }
    }
}
