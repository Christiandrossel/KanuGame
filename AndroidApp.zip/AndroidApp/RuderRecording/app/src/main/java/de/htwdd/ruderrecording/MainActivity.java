package de.htwdd.ruderrecording;

import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;

import android.view.View;
import de.htwdd.ruderrecording.sensors.SensorListener;
import de.htwdd.ruderrecording.sensors.SensorService;

import java.text.SimpleDateFormat;
import java.util.Date;

public class MainActivity extends AppCompatActivity {

    private static final long UPDATE_RATE = 100;
    private SensorService _sensorService = null;

    private FloatingActionButton _fab = null;
    private FileService _fileService;
    private boolean _recording = false;
    private long _lastUpdate;

    private SensorListener _fileListener = new SensorListener() {
        @Override
        public void onSensorUpdate(float[] acceleration, float[] orientation) {
            if(_recording && System.currentTimeMillis() - UPDATE_RATE >= _lastUpdate) {
                SimpleDateFormat format = new SimpleDateFormat("hh:mm:ss,SS");
                String timestamp = format.format(new Date());

                for (int i = 0; i<orientation.length; i++)
                        orientation[i] = (float) (orientation[i] * (180 / Math.PI));

                String line = String.format("%+6.3f_;_%+6.3f_;_%+6.3f_||_%+6.3f_;_%+6.3f_;_%+6.3f__" + timestamp + "\n",
                        orientation[0], orientation[1], orientation[2], acceleration[0], acceleration[1], acceleration[2]);

                _fileService.writeToFile(line);
                _lastUpdate = System.currentTimeMillis();
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        _sensorService = new SensorService(this);
        MainFragment fragment = new MainFragment();
        _sensorService.registerListener(fragment);
        _sensorService.startSensors();

        _fileService = new FileService(this);

        FragmentManager fragManager = getSupportFragmentManager();
        fragManager.beginTransaction()
                .replace(R.id.fragment_container, fragment)
                .commit();
    }

    @Override
    protected void onStart() {
        _fab = findViewById(R.id.fab);
        _fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!_recording) {
                    _fileService.setFile(null);
                    _recording = true;
                    _fab.setImageDrawable(getResources().getDrawable(R.drawable.ic_stop));
                    _sensorService.registerListener(_fileListener);
                } else {
                    _recording = false;
                    _fab.setImageDrawable(getResources().getDrawable(R.drawable.ic_start));
                    _sensorService.unregisterListener(_fileListener);
                }
            }
        });
        super.onStart();
    }

    @Override
    protected void onDestroy() {
        _sensorService.stopSensors();
        super.onDestroy();
    }
}