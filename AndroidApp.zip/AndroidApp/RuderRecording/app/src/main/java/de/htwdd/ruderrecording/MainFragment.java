package de.htwdd.ruderrecording;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import de.htwdd.ruderrecording.sensors.SensorListener;

import java.text.SimpleDateFormat;
import java.util.Date;

public class MainFragment extends Fragment implements SensorListener
{
    public static final String TAG = "MainFragment";
    private static final int UPDATE_RATE = 100;

    private TextView[] _gyro = new TextView[3];
    private TextView[] _accelero = new TextView[3];
    private FloatingActionButton _fab = null;

    private long _lastUpdate;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_main, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        _setupGui(view);

        super.onViewCreated(view, savedInstanceState);
    }

    //////////////////////////////////////////
    // SensorListener implementation

    @Override
    public void onSensorUpdate(float[] acceleration, float[] orientation) {
        if(System.currentTimeMillis() - UPDATE_RATE >= _lastUpdate) {
            for (int i = 0; i < acceleration.length; i++) {
                if (_accelero[i] != null) {
                    String text = getString(R.string.val_accelero, acceleration[i]);
                    _accelero[i].setText(text);
                }
                if (_gyro[i] != null) {
                    double value = orientation[i] * (180 / Math.PI);
                    String text = getString(R.string.val_gyro, value);
                    _gyro[i].setText(text);
                }
            }
            _lastUpdate = System.currentTimeMillis();
        }
    }

    //////////////////////////////////////////
    // private methods

    private void _setupGui(View view) {
        _gyro[0] = view.findViewById(R.id.val_gyro_x);
        _gyro[1] = view.findViewById(R.id.val_gyro_y);
        _gyro[2] = view.findViewById(R.id.val_gyro_z);

        _accelero[0] = view.findViewById(R.id.val_accelero_x);
        _accelero[1] = view.findViewById(R.id.val_accelero_y);
        _accelero[2] = view.findViewById(R.id.val_accelero_z);
    }
}
